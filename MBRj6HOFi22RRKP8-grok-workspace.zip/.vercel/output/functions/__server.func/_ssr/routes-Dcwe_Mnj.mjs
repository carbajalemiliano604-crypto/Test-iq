import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as ArrowRight, _ as CircleCheck, a as SlidersHorizontal, b as Bookmark, c as Pause, d as ListChecks, f as LayoutGrid, g as Clock3, h as Clock, l as Palette, m as Crown, n as User, o as RotateCcw, p as Layers, r as Trophy, s as Play, t as X, u as Medal, v as ChevronRight, x as Award, y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Root2, i as Portal2, n as Item2, o as Trigger, r as Label2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { a as ReferenceLine, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dcwe_Mnj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function shuffle(arr) {
	const next = [...arr];
	for (let i = next.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[next[i], next[j]] = [next[j], next[i]];
	}
	return next;
}
function formatTime(totalSeconds) {
	return `${Math.floor(totalSeconds / 60).toString().padStart(2, "0")}:${Math.floor(totalSeconds % 60).toString().padStart(2, "0")}`;
}
function makeCertCode() {
	return `IQM-${Date.now().toString(36).toUpperCase().slice(-4)}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-semibold transition-colors duration-150 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-on-primary hover:bg-primary-hover shadow-sm",
			outline: "border border-border bg-background text-foreground hover:border-primary",
			ghost: "text-muted hover:text-foreground hover:bg-background",
			gold: "border border-gold/40 bg-gold/15 text-gold hover:bg-gold/25",
			secondary: "bg-secondary text-on-primary hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5 text-base",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		type: asChild ? void 0 : type ?? "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
});
Button.displayName = "Button";
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuPortal = Portal2;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 8, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-48 overflow-hidden rounded-2xl border border-border bg-card p-2 text-foreground shadow-2xl", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("flex cursor-pointer items-center justify-between rounded-xl px-3 py-2 text-xs font-medium outline-none hover:bg-background focus:bg-background", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1 text-xs font-semibold text-muted", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var THEME_META = [
	{
		id: "indigo",
		label: "Neon Indigo",
		swatch: "swatch-indigo"
	},
	{
		id: "emerald",
		label: "Cyber Emerald",
		swatch: "swatch-emerald"
	},
	{
		id: "purple",
		label: "Royal Purple",
		swatch: "swatch-purple"
	},
	{
		id: "sunset",
		label: "Sunset Amber",
		swatch: "swatch-sunset"
	},
	{
		id: "ocean",
		label: "Ocean Deep",
		swatch: "swatch-ocean"
	},
	{
		id: "light",
		label: "Modo Claro",
		swatch: "swatch-light"
	}
];
function AppHeader({ theme, onTheme, onHome, onLeaderboard, onHistory }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-card/85 backdrop-blur-md no-print",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onHome,
				className: "text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-black tracking-wider text-foreground",
					children: "IQ Metrics Pro"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[10px] font-bold uppercase tracking-widest text-muted",
					children: "Evaluación Psicométrica Estandarizada"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 sm:gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "gold",
						size: "sm",
						onClick: onLeaderboard,
						className: "rounded-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Tabla Top"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "rounded-xl bg-background",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Tema"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Elegir esquema" }), THEME_META.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							onSelect: () => onTheme(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn(theme === item.id && "text-primary"),
								children: item.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-3 rounded-full", item.swatch) })]
						}, item.id))]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: onHistory,
						className: "rounded-xl bg-background",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Historial"
						})]
					})
				]
			})]
		})
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-overlay backdrop-blur-sm", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, showClose = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-border bg-card p-6 text-foreground shadow-2xl focus:outline-none", className),
	...props,
	children: [children, showClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
		className: "absolute right-4 top-4 rounded-lg p-1 text-muted hover:text-foreground",
		"aria-label": "Cerrar",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
	}) : null]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 space-y-1 pr-8", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-lg font-bold tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-xs text-muted", className),
		...props
	});
}
function LeaderboardModal({ open, onOpenChange, entries, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-5 text-gold" }), " Tabla Top de CI"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Clasificación en tiempo real. Los lugares se mueven según la puntuación de CI y la velocidad de resolución." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-80 space-y-2 overflow-y-auto pr-1 text-xs",
				children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-8 text-center text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "mx-auto mb-2 size-8 text-gold/40" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "La Tabla Top está vacía"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[11px]",
							children: "Completa una evaluación para registrar tu puntuación."
						})
					]
				}) : entries.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex items-center justify-between rounded-2xl border p-3", idx === 0 ? "border-gold/40 bg-gold/10 text-gold" : idx === 1 ? "border-border bg-background" : idx === 2 ? "border-warning/30 bg-warning/10 text-warning" : "border-border bg-background"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-center text-sm font-extrabold",
							children: idx + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-bold",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[10px] opacity-70",
							children: [
								item.date,
								" · ",
								formatTime(item.timeSeconds),
								" min"
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-base font-black text-primary",
						children: [
							item.iq,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-normal text-muted",
								children: "CI"
							})
						]
					})]
				}, `${item.name}-${item.date}-${idx}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-t border-border pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onReset,
					className: "text-[11px] text-danger hover:underline",
					children: "Vaciar Tabla Top"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => onOpenChange(false),
					children: "Cerrar"
				})]
			})
		] })
	});
}
function HistoryModal({ open, onOpenChange, entries, onClear }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Historial de intentos" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-72 space-y-2 overflow-y-auto text-xs",
				children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-muted",
					children: "Todavía no hay intentos guardados."
				}) : entries.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between rounded-2xl border border-border bg-background p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] text-muted",
						children: [
							item.date,
							" · ",
							item.correct,
							"/",
							item.total,
							" · ",
							formatTime(item.seconds)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-base font-black text-primary",
							children: [item.iq, " CI"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted",
							children: item.classification
						})]
					})]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClear,
					className: "text-xs text-danger hover:underline",
					children: "Limpiar historial"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => onOpenChange(false),
					children: "Cerrar"
				})]
			})
		] })
	});
}
function QuestionGridModal({ open, onOpenChange, questions, answers, flagged, index, onJump }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Mapa del test" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid max-h-60 grid-cols-5 gap-2 overflow-y-auto p-1",
					children: questions.map((q, i) => {
						const answered = answers[i] !== null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onJump(i),
							className: cn("flex h-11 items-center justify-center rounded-xl border text-xs font-bold", i === index ? "border-primary bg-primary text-on-primary" : flagged[i] ? "border-gold bg-gold/15 text-gold" : answered ? "border-primary/40 bg-primary/10 text-primary" : "border-border bg-background"),
							children: i + 1
						}, q.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "w-full",
					onClick: () => onOpenChange(false),
					children: "Cerrar"
				})
			]
		})
	});
}
function FinishConfirmModal({ open, onOpenChange, unanswered, onReview, onFinish }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Hay preguntas sin responder" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				"Quedan ",
				unanswered,
				" ",
				unanswered === 1 ? "pregunta" : "preguntas",
				" en blanco. Puedes revisarlas o enviar el test ahora."
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row sm:justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onReview,
					children: "Revisar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onFinish,
					children: "Enviar de todos modos"
				})]
			})]
		})
	});
}
function CertificateModal({ open, onOpenChange, results }) {
	if (!results) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "print-area max-w-2xl space-y-6 bg-card p-8 text-center",
			showClose: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-border pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "mx-auto mb-2 size-12 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-2xl font-extrabold uppercase tracking-widest text-primary",
							children: "Certificado Oficial de Desempeño"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "IQ METRICS PSYCHOMETRIC EVALUATION" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Se certifica que",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-primary",
							children: results.username
						}),
						" ha completado la evaluación psicométrica estandarizada obteniendo:"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-block rounded-2xl border border-primary/30 bg-background px-8 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs font-semibold uppercase text-muted",
							children: "Coeficiente intelectual estimado"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-5xl font-black text-primary tabular-nums",
							children: results.iq
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm font-bold",
							children: results.classification
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-md grid-cols-2 gap-4 pt-2 text-left text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-background p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-muted",
							children: "Fecha de emisión"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: results.dateLabel })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-background p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-muted",
							children: "Código de verificación"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono",
							children: results.certCode
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center gap-3 pt-2 no-print",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => window.print(),
						children: "Imprimir / Guardar en PDF"
					})
				})
			]
		})
	});
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function erf(x) {
	const sign = x < 0 ? -1 : 1;
	const ax = Math.abs(x);
	const a1 = .254829592;
	const a2 = -.284496736;
	const a3 = 1.421413741;
	const a4 = -1.453152027;
	const a5 = 1.061405429;
	const t = 1 / (1 + .3275911 * ax);
	return sign * (1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-ax * ax));
}
function classifyIq(iq) {
	if (iq >= 145) return "Genio";
	if (iq >= 130) return "Muy superior";
	if (iq >= 120) return "Superior";
	if (iq >= 110) return "Por encima del promedio";
	if (iq >= 90) return "Promedio";
	if (iq >= 80) return "Por debajo del promedio";
	return "Límite";
}
function percentileFromIq(iq) {
	const p = .5 * (1 + erf((iq - 100) / 15 / Math.SQRT2));
	return Math.round(clamp(p * 100, 1, 99));
}
/** Standardized estimate: accuracy maps to ~70–142, speed trims ±12. */
function computeIq(correct, total, seconds) {
	const accuracy = total === 0 ? 0 : correct / total;
	const base = 70 + accuracy * 72;
	const avg = seconds / Math.max(total, 1);
	let adj = 0;
	if (accuracy >= .45) {
		if (avg < 10) adj = 12;
		else if (avg < 16) adj = 7;
		else if (avg < 24) adj = 3;
		else if (avg > 55) adj = -8;
		else if (avg > 40) adj = -4;
	} else if (avg > 50) adj = -4;
	return Math.round(clamp(base + adj, 70, 160));
}
function countCorrect(questions, answers) {
	return questions.reduce((sum, q, i) => {
		return sum + (answers[i] === q.correct ? 1 : 0);
	}, 0);
}
function categoryBreakdown(questions, answers) {
	const map = /* @__PURE__ */ new Map();
	questions.forEach((q, i) => {
		const row = map.get(q.category) ?? {
			category: q.category,
			correct: 0,
			total: 0
		};
		row.total += 1;
		if (answers[i] === q.correct) row.correct += 1;
		map.set(q.category, row);
	});
	return [...map.values()].sort((a, b) => b.total - a.total);
}
function gaussPoints(userIq) {
	const pts = [];
	for (let x = 55; x <= 145; x += 1) {
		const density = Math.exp(-.5 * ((x - 100) / 15) ** 2);
		pts.push({
			iq: x,
			density,
			user: x === Math.round(clamp(userIq, 55, 145)) ? density : null
		});
	}
	return pts;
}
function GaussChart({ iq }) {
	const data = (0, import_react.useMemo)(() => gaussPoints(iq), [iq]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative h-52 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: -20,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "gaussFill",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "var(--color-primary)",
							stopOpacity: .45
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "var(--color-primary)",
							stopOpacity: .02
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "iq",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 10
						},
						tickLine: false,
						axisLine: false,
						ticks: [
							70,
							85,
							100,
							115,
							130,
							145
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: {
							background: "var(--color-card)",
							border: "1px solid var(--color-border)",
							borderRadius: 12,
							fontSize: 12
						},
						formatter: (_value, _name, item) => {
							return [`CI ${(item?.payload)?.iq ?? ""}`, "Distribución"];
						},
						labelFormatter: () => ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "density",
						stroke: "var(--color-chart)",
						strokeWidth: 2,
						fill: "url(#gaussFill)",
						isAnimationActive: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
						x: iq,
						stroke: "var(--color-gold)",
						strokeWidth: 2,
						strokeDasharray: "4 3",
						label: {
							value: `Tú · ${iq}`,
							fill: "var(--color-gold)",
							fontSize: 11,
							fontWeight: 700,
							position: "top"
						}
					})
				]
			})
		})
	});
}
function Frame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex min-h-[180px] w-full items-center justify-center rounded-2xl border border-border bg-background p-4 md:p-6", className),
		children
	});
}
function Cell({ children, missing }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-16 w-28 items-center justify-center rounded-lg border", missing ? "border-dashed border-primary" : "border-border bg-card"),
		children
	});
}
function Matrix2x2() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-8 rounded-full bg-primary" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "relative size-8 rounded-full bg-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-on-primary" })
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-8 rounded-sm bg-secondary" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
				missing: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xl font-bold text-primary",
					children: "?"
				})
			})
		]
	});
}
function Chips({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap items-center justify-center gap-2 font-mono text-sm font-bold",
		children: items.map((item, i) => {
			const isQ = item === "?" || item === "X" || item.endsWith("?");
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("rounded-lg border px-2.5 py-1.5", isQ ? "border-primary bg-primary text-on-primary" : "border-border bg-card text-foreground"),
				children: item
			}, `${item}-${i}`);
		})
	});
}
function Premises({ lines }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "w-full max-w-md space-y-1 rounded-xl border border-border bg-card px-4 py-3 text-center text-xs font-semibold",
		children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-foreground",
			children: line
		}, line))
	});
}
function Analogy({ left, right, target }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-center text-sm font-bold tracking-wide text-foreground",
		children: [
			left,
			" : ",
			right,
			" :: ",
			target,
			" : ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-primary",
				children: "?"
			})
		]
	});
}
function ArrowIcon({ dir }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 48 48",
		className: cn("size-10 text-chart", dir === "right" ? "rotate-0" : dir === "down" ? "rotate-90" : dir === "left" ? "rotate-180" : "-rotate-90"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 24h22M26 16l10 8-10 8",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "3",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function Arrows() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap items-center justify-center gap-2",
		children: [
			"right",
			"down",
			"left",
			null
		].map((dir, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("flex size-16 items-center justify-center rounded-lg border bg-card", dir ? "border-border" : "border-dashed border-primary"),
			children: dir ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowIcon, { dir }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-lg font-bold text-primary",
				children: "?"
			})
		}, i))
	});
}
function LetterShift() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card px-5 py-4 text-center font-mono text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["MENTE → ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-bold text-primary",
			children: "NFPUI"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1",
			children: ["LOGICA → ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-bold text-primary",
				children: "?"
			})]
		})]
	});
}
function Pyramid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 text-center text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-5 rounded-sm bg-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-5 rounded-sm bg-primary/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-5 rounded-sm bg-primary/80" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-5 rounded-sm bg-primary/60" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-5 rounded-sm bg-primary/60" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-5 rounded-sm bg-primary/60" })
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card px-4 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nivel 1 (base): 3×3 cubos" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nivel 2 (centro): 2×2 cubos" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nivel 3 (cúspide): 1×1 cubo" })
			]
		})]
	});
}
function Race() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-sm space-y-1 rounded-xl border border-border bg-card px-4 py-3 text-center text-xs font-semibold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Daniel → Carlos → Beatriz" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-primary",
			children: "Esteban → Daniel"
		})]
	});
}
function MulBoxes() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1 rounded-xl border border-border bg-card px-5 py-3 text-center font-mono text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "3 × 4 = 12" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "5 × 6 = 30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold text-primary",
				children: "7 × 8 = ?"
			})
		]
	});
}
function Rotate180() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-10 items-center justify-center rounded-md bg-primary text-[10px] font-bold text-on-primary",
						children: "SI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-md border border-border bg-card" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-md border border-border bg-card" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-md border border-border bg-card" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-bold text-muted",
				children: "180°"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-md border border-dashed border-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-md border border-border bg-card" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-md border border-border bg-card" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-10 items-center justify-center rounded-md border border-dashed border-primary text-sm font-bold text-primary",
						children: "?"
					})
				]
			})
		]
	});
}
function OddGroup({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap justify-center gap-2",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold",
			children: item
		}, item))
	});
}
function Cylinder() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 80 90",
			className: "h-20 w-16 text-chart",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "40",
					cy: "18",
					rx: "28",
					ry: "12",
					fill: "currentColor",
					opacity: "0.35"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M12 18 v50 a28 12 0 0 0 56 0 V18",
					fill: "currentColor",
					opacity: "0.2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "40",
					cy: "18",
					rx: "28",
					ry: "12",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M12 18 v50",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M68 18 v50",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "40",
					cy: "68",
					rx: "28",
					ry: "12",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center text-xs font-bold text-muted",
			children: ["Vista superior", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex size-12 items-center justify-center rounded-full border border-dashed border-primary text-primary",
				children: "?"
			})]
		})]
	});
}
function RgbMix() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 text-xs font-bold",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-danger px-3 py-2 text-on-primary",
				children: "Rojo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: "+"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-success px-3 py-2 text-background",
				children: "Verde"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: "="
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-dashed border-primary px-3 py-2 text-primary",
				children: "?"
			})
		]
	});
}
function Matrix3x3() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-1.5 font-mono text-sm font-bold",
		children: [
			"1",
			"2",
			"3",
			"2",
			"4",
			"6",
			"3",
			"6",
			"?"
		].map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("flex size-12 items-center justify-center rounded-lg border", c === "?" ? "border-primary bg-primary text-on-primary" : "border-border bg-card"),
			children: c
		}, i))
	});
}
function Weekday() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card px-5 py-3 text-center text-xs font-bold",
		children: ["Hoy = Martes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-primary",
			children: "¿Día en +15 días?"
		})]
	});
}
function MathExpr({ expr }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "rounded-xl border border-border bg-card px-5 py-3 font-mono text-sm font-bold",
		children: [
			expr,
			" = ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-primary",
				children: "?"
			})
		]
	});
}
function CubeNet() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 rounded-sm border border-border bg-primary/30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 rounded-sm border border-border bg-primary/40" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 rounded-sm border border-border bg-primary/70" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 rounded-sm border border-border bg-primary/40" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 rounded-sm border border-border bg-primary/40" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 rounded-sm border border-border bg-primary/30" })
		]
	});
}
function Note({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-md rounded-xl border border-border bg-card px-4 py-3 text-center text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-bold text-primary",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-muted",
			children: body
		})]
	});
}
function QuestionVisual({ visual }) {
	let inner;
	switch (visual.type) {
		case "matrix2x2":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matrix2x2, {});
			break;
		case "chips":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, { items: visual.items });
			break;
		case "premises":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Premises, { lines: visual.lines });
			break;
		case "analogy":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Analogy, {
				left: visual.left,
				right: visual.right,
				target: visual.target
			});
			break;
		case "arrows":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrows, {});
			break;
		case "letterShift":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterShift, {});
			break;
		case "pyramid":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pyramid, {});
			break;
		case "race":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Race, {});
			break;
		case "mulBoxes":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MulBoxes, {});
			break;
		case "rotate180":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rotate180, {});
			break;
		case "oddGroup":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OddGroup, { items: visual.items });
			break;
		case "cylinder":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cylinder, {});
			break;
		case "rgbMix":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RgbMix, {});
			break;
		case "matrix3x3":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matrix3x3, {});
			break;
		case "weekday":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Weekday, {});
			break;
		case "mathExpr":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MathExpr, { expr: visual.expr });
			break;
		case "cubeNet":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CubeNet, {});
			break;
		case "note":
			inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
				title: visual.title,
				body: visual.body
			});
			break;
		default: inner = null;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: inner });
}
function IqGauge({ iq }) {
	const [shown, setShown] = (0, import_react.useState)(70);
	(0, import_react.useEffect)(() => {
		const start = performance.now();
		const from = 70;
		const dur = 700;
		let raf = 0;
		const tick = (now) => {
			const t = Math.min(1, (now - start) / dur);
			setShown(Math.round(from + (iq - from) * t));
			if (t < 1) raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [iq]);
	const c = 2 * Math.PI * 42;
	const pct = (shown - 70) / 90;
	const offset = c * (1 - Math.min(1, Math.max(0, pct)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex size-40 items-center justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "size-full -rotate-90",
			viewBox: "0 0 100 100",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "50",
				cy: "50",
				r: "42",
				stroke: "currentColor",
				strokeWidth: "8",
				className: "text-border",
				fill: "transparent"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "50",
				cy: "50",
				r: "42",
				stroke: "currentColor",
				strokeWidth: "8",
				className: "text-primary transition-[stroke-dashoffset] duration-700",
				fill: "transparent",
				strokeDasharray: c,
				strokeDashoffset: offset,
				strokeLinecap: "round"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-4xl font-black leading-none text-primary tabular-nums",
				children: shown
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] font-bold uppercase tracking-wider text-muted",
				children: "Puntuación CI"
			})]
		})]
	});
}
function ResultsScreen({ results, questions, answers, reviewOpen, onToggleReview, onLeaderboard, onCertificate, onRestart }) {
	const podium = results.rank === 1 ? "Nuevo récord. Ocupas el Top 1 de la tabla." : results.rank <= 3 ? `Estás en el podio. Puesto #${results.rank}.` : results.rank <= 10 ? `Entraste al Top 10. Puesto #${results.rank}.` : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "w-full max-w-4xl space-y-10 rounded-3xl border border-border bg-card p-6 shadow-2xl md:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-full border border-success/20 bg-success/10 px-3 py-1 text-xs font-semibold text-success",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), " Evaluación completada"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-extrabold text-foreground md:text-4xl",
						children: "Tu perfil intelectual"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto max-w-xl text-xs text-muted md:text-sm",
						children: "Resultado de CI calculado con ajuste psicométrico estandarizado y velocidad de respuesta."
					})
				]
			}),
			podium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-gold/40 bg-gold/10 p-4 text-center text-sm font-bold text-gold",
				children: podium
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 items-center gap-6 rounded-2xl border border-border bg-background p-6 md:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center justify-center md:border-r md:border-border md:pr-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IqGauge, { iq: results.iq }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 text-center text-sm font-bold text-primary",
						children: results.classification
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-3 md:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Aciertos total",
							value: `${results.correct}/${results.total}`,
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Tiempo empleado",
							value: formatTime(results.seconds)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Percentil global",
							value: `${results.percentile}%`,
							tone: "secondary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Puesto Top",
							value: `#${results.rank}`,
							tone: "gold"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Precisión",
							value: `${results.accuracy}%`,
							tone: "chart",
							className: "col-span-2 sm:col-span-2"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between rounded-2xl border border-border bg-background p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "mb-1 flex items-center gap-2 text-sm font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-4 text-primary" }), " Curva normal de Gauss"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs text-muted",
						children: "Tu ubicación dentro de la distribución poblacional."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GaussChart, { iq: results.iq })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-2xl border border-border bg-background p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "flex items-center gap-2 text-sm font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-4 text-primary" }), " Dominios cognitivos"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: results.categories.map((cat) => {
							const pct = cat.total ? Math.round(cat.correct / cat.total * 100) : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: cat.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-muted",
									children: [
										cat.correct,
										"/",
										cat.total,
										" · ",
										pct,
										"%"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 overflow-hidden rounded-full bg-card",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-primary",
									style: { width: `${pct}%` }
								})
							})] }, cat.category);
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap justify-center gap-3 no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "gold",
						onClick: onLeaderboard,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4" }), " Ver Tabla Top"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: onToggleReview,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "size-4 text-primary" }), " Explicaciones paso a paso"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: onCertificate,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4" }), " Certificado"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onRestart,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), " Nuevo test"]
					})
				]
			}),
			reviewOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 border-t border-border pt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "flex items-center gap-2 text-lg font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "size-5 text-primary" }), " Solucionario detallado"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: questions.map((q, i) => {
						const chosen = answers[i];
						const ok = chosen === q.correct;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "space-y-3 rounded-2xl border border-border bg-background p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-bold",
										children: [
											i + 1,
											". ",
											q.question
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", chosen === null ? "bg-muted/20 text-muted" : ok ? "bg-success/15 text-success" : "bg-danger/15 text-danger"),
										children: chosen === null ? "Sin respuesta" : ok ? "Correcta" : "Incorrecta"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionVisual, { visual: q.visual }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "grid gap-1.5 text-xs sm:grid-cols-2",
									children: q.options.map((opt, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: cn("rounded-xl border px-3 py-2", idx === q.correct ? "border-success/40 bg-success/10" : idx === chosen ? "border-danger/40 bg-danger/10" : "border-border"),
										children: opt
									}, opt))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs leading-relaxed text-muted",
									children: q.explanation
								})
							]
						}, q.id);
					})
				})]
			}) : null
		]
	});
}
function Stat({ label, value, tone, className }) {
	const color = tone === "success" ? "text-success" : tone === "secondary" ? "text-secondary" : tone === "gold" ? "text-gold" : tone === "chart" ? "text-chart" : "text-foreground";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-2xl border border-border bg-card p-3.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-xl font-extrabold tabular-nums", color),
			children: value
		})]
	});
}
var Input = import_react.forwardRef(({ className, type = "text", ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		type,
		className: cn("flex h-12 w-full rounded-xl border border-border bg-card px-4 text-sm font-semibold text-foreground placeholder:text-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50", className),
		...props
	});
});
Input.displayName = "Input";
var MODES = [
	{
		value: 10,
		title: "Rápido",
		hint: "10 preguntas"
	},
	{
		value: 15,
		title: "Estándar",
		hint: "15 preguntas"
	},
	{
		value: 25,
		title: "Exhaustivo",
		hint: "25 preguntas"
	}
];
function RankBadge({ index }) {
	if (index === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4 text-gold" });
	if (index === 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medal, { className: "size-4 text-muted" });
	if (index === 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medal, { className: "size-4 text-warning" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "w-4 text-muted",
		children: ["#", index + 1]
	});
}
function StartScreen({ username, onUsername, length, onLength, leaderboard, onOpenLeaderboard, onStart }) {
	const top = leaderboard.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative w-full max-w-2xl overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-2xl md:p-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 space-y-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-extrabold tracking-tight text-foreground md:text-4xl",
					children: "Test Adaptativo de Inteligencia"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-lg text-sm text-muted md:text-base",
					children: "Evaluación psicométrica completa. Preguntas barajadas, ranking competitivo y certificado oficial."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 rounded-2xl border border-border bg-background p-4 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: "username-input",
						className: "block text-xs font-bold uppercase tracking-wider text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "mr-1 inline size-3.5 text-primary" }), " Tu nombre para la Tabla Top"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "username-input",
						value: username,
						onChange: (e) => onUsername(e.target.value),
						placeholder: "Escribe tu nombre aquí...",
						autoComplete: "nickname",
						maxLength: 32
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-2xl border border-border bg-background p-4 text-left md:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-bold uppercase tracking-wider text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "mr-1 inline size-3.5 text-primary" }), " Número de preguntas"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-3",
						children: MODES.map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onLength(mode.value),
							className: cn("rounded-xl border bg-card p-3.5 text-center transition-colors", length === mode.value ? "border-primary bg-primary/10" : "border-border hover:border-primary"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-foreground",
								children: mode.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: mode.hint
							})]
						}, mode.value))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 rounded-2xl border border-border bg-background p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 font-bold uppercase tracking-wider text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "size-3.5" }), " Clasificación actual"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onOpenLeaderboard,
							className: "font-semibold text-primary hover:underline",
							children: "Ver todo"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-1 text-xs",
						children: top.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-4 text-center text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "mx-auto mb-1 size-6 text-gold/40" }), "Aún no hay participantes. Sé el primero y toma el Top 1."]
						}) : top.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-xl border border-border bg-card p-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankBadge, { index: idx }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: item.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-extrabold text-primary",
								children: [item.iq, " CI"]
							})]
						}, `${item.name}-${item.date}-${idx}`))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onStart,
					size: "lg",
					className: "h-14 w-full rounded-2xl text-lg shadow-lg",
					children: ["Iniciar Evaluación", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5" })]
				})
			]
		})
	});
}
var LETTERS = [
	"A",
	"B",
	"C",
	"D"
];
function TestScreen({ questions, index, answers, flagged, seconds, paused, onSelect, onPrev, onNext, onFlag, onPause, onOpenGrid }) {
	const q = questions[index];
	if (!q) return null;
	const total = questions.length;
	const isLast = index === total - 1;
	const answered = answers.filter((a) => a !== null).length;
	const pct = (index + 1) / total * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "w-full max-w-3xl space-y-6 rounded-3xl border border-border bg-card p-5 shadow-2xl md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center justify-between gap-4 border-b border-border pb-4 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-xl border border-primary/30 bg-primary/20 px-3 py-1.5 text-xs font-bold text-primary",
							children: [
								"Pregunta ",
								index + 1,
								"/",
								total
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-xl border border-border bg-background px-3 py-1.5 text-xs font-medium text-muted",
							children: q.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onFlag,
							className: "rounded-lg border border-border p-2 text-muted hover:text-gold",
							title: "Marcar para revisar",
							"aria-label": "Marcar para revisar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-4", flagged[index] && "fill-gold text-gold") })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm font-bold tabular-nums",
							children: formatTime(seconds)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon-sm",
						onClick: onPause,
						className: "rounded-xl bg-background",
						title: paused ? "Reanudar" : "Pausar",
						"aria-label": paused ? "Reanudar" : "Pausar",
						children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-3.5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-2 w-full overflow-hidden rounded-full bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-primary transition-[width] duration-300",
					style: { width: `${pct}%` }
				})
			}),
			paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-[220px] flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-background",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-bold",
						children: "Evaluación en pausa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "El cronómetro está detenido. Reanuda para continuar."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-4",
						onClick: onPause,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), " Reanudar"]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold leading-snug text-foreground md:text-xl",
						children: q.question
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionVisual, { visual: q.visual }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: q.options.map((opt, idx) => {
							const selected = answers[index] === idx;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onSelect(idx),
								className: cn("flex min-h-14 w-full items-center justify-between gap-3 rounded-2xl border p-4 text-left text-sm font-medium transition-colors", selected ? "border-primary bg-primary/10 text-foreground" : "border-border bg-background text-foreground hover:border-primary"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: opt }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("flex size-7 shrink-0 items-center justify-center rounded-lg border text-xs font-bold", selected ? "border-primary bg-primary text-on-primary" : "border-border text-muted"),
									children: LETTERS[idx]
								})]
							}, `${q.id}-${idx}`);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: onPrev,
						disabled: index === 0,
						className: "rounded-xl bg-background",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), " Anterior"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onOpenGrid,
						className: "flex items-center gap-1 text-xs font-semibold text-primary hover:underline",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-3.5" }),
							" Vista general (",
							answered,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onNext,
						className: "rounded-xl",
						children: [isLast ? "Finalizar" : "Siguiente", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
					})
				]
			})
		]
	});
}
var QUESTION_BANK = [
	{
		id: "q1",
		category: "Razonamiento Espacial",
		question: "¿Qué figura completa lógicamente la matriz 2×2?",
		visual: { type: "matrix2x2" },
		options: [
			"Cuadrado púrpura con punto blanco central",
			"Círculo azul con cuadrado central",
			"Cuadrado púrpura totalmente vacío",
			"Triángulo púrpura con punto central"
		],
		correct: 0,
		explanation: "En la fila superior, la figura añade un punto blanco central en la casilla derecha. Por analogía, el cuadrado púrpura debe mantener su figura e incorporar el punto blanco central."
	},
	{
		id: "q2",
		category: "Lógica Numérica",
		question: "Determina el número faltante en la serie: 4, 9, 19, 39, 79, ___",
		visual: {
			type: "chips",
			items: [
				"4",
				"9",
				"19",
				"39",
				"79",
				"?"
			]
		},
		options: [
			"159",
			"149",
			"158",
			"169"
		],
		correct: 0,
		explanation: "La regla de progresión es duplicar el valor previo y sumar 1 (×2 + 1). Así: 79 × 2 + 1 = 159."
	},
	{
		id: "q3",
		category: "Razonamiento Lógico",
		question: "Si todo A es B, y ningún B es C, ¿cuál es la única deducción formalmente válida?",
		visual: {
			type: "premises",
			lines: ["Premisa 1: Todo [A] pertenece a [B]", "Premisa 2: Ningún [B] pertenece a [C]"]
		},
		options: [
			"Ningún A es C",
			"Algunos A son C",
			"Todo C es A",
			"Ninguna de las anteriores"
		],
		correct: 0,
		explanation: "Dado que A está completamente contenido dentro del conjunto B, y B está totalmente excluido de C, resulta imposible que algún A pertenezca a C."
	},
	{
		id: "q4",
		category: "Analogías Verbales",
		question: "TELESCOPIO es a ESTRELLA como MICROSCOPIO es a:",
		visual: {
			type: "analogy",
			left: "TELESCOPIO",
			right: "ESTRELLA",
			target: "MICROSCOPIO"
		},
		options: [
			"Célula / Bacteria",
			"Lente",
			"Laboratorio",
			"Planeta"
		],
		correct: 0,
		explanation: "El telescopio es una herramienta diseñada para observar objetos lejanos (estrellas), mientras que el microscopio se utiliza para observar estructuras microscópicas (células)."
	},
	{
		id: "q5",
		category: "Patrones Visoespaciales",
		question: "¿Hacia dónde apunta la flecha en la cuarta etapa de la secuencia?",
		visual: { type: "arrows" },
		options: [
			"Hacia arriba (↑)",
			"Hacia abajo (↓)",
			"Hacia la derecha (→)",
			"Hacia la izquierda (←)"
		],
		correct: 0,
		explanation: "La flecha rota 90 grados en sentido horario en cada paso: Derecha → Abajo → Izquierda → Arriba."
	},
	{
		id: "q6",
		category: "Lógica Numérica",
		question: "¿Qué número reemplaza el signo de interrogación? 2, 3, 5, 7, 11, 13, ___",
		visual: {
			type: "chips",
			items: [
				"2",
				"3",
				"5",
				"7",
				"11",
				"13",
				"?"
			]
		},
		options: [
			"17",
			"15",
			"19",
			"21"
		],
		correct: 0,
		explanation: "Es la serie de números primos en orden ascendente. El número primo sucesor de 13 es 17."
	},
	{
		id: "q7",
		category: "Memoria y Velocidad",
		question: "Si «MENTE» se transforma en «NFPUI» (desplazando +1 cada letra), ¿cómo se transforma «LOGICA»?",
		visual: { type: "letterShift" },
		options: [
			"MPHJDB",
			"MOHJDB",
			"NPHJDC",
			"LOHJDB"
		],
		correct: 0,
		explanation: "Avanzando cada carácter un puesto en el alfabeto: L→M, O→P, G→H, I→J, C→D, A→B. Resultado: MPHJDB."
	},
	{
		id: "q8",
		category: "Razonamiento Espacial",
		question: "¿Cuántos cubos individuales forman una pirámide cuadrada de base 3×3?",
		visual: { type: "pyramid" },
		options: [
			"14 cubos",
			"12 cubos",
			"10 cubos",
			"15 cubos"
		],
		correct: 0,
		explanation: "Sumando los bloques por cada nivel: 3² + 2² + 1² = 9 + 4 + 1 = 14 cubos."
	},
	{
		id: "q9",
		category: "Analogías Verbales",
		question: "BRÚJULA es a ORIENTACIÓN como RELOJ es a:",
		visual: {
			type: "analogy",
			left: "BRÚJULA",
			right: "ORIENTACIÓN",
			target: "RELOJ"
		},
		options: [
			"Medición del Tiempo",
			"Segundos",
			"Muñeca",
			"Alarma"
		],
		correct: 0,
		explanation: "La brújula mide/indica la orientación, mientras que el reloj mide el tiempo."
	},
	{
		id: "q10",
		category: "Razonamiento Lógico",
		question: "En una competencia, Carlos llegó antes que Beatriz, pero después de Daniel. Esteban llegó antes que Daniel. ¿Quién ganó la carrera?",
		visual: { type: "race" },
		options: [
			"Esteban",
			"Daniel",
			"Carlos",
			"Beatriz"
		],
		correct: 0,
		explanation: "El orden completo de llegada es: Esteban > Daniel > Carlos > Beatriz. El ganador es Esteban."
	},
	{
		id: "q11",
		category: "Matrices Abstractas",
		question: "¿Qué cantidad de elementos debe tener la quinta figura según el patrón: 1, 3, 6, 10, ___?",
		visual: {
			type: "chips",
			items: [
				"F1: 1",
				"F2: 3",
				"F3: 6",
				"F4: 10",
				"F5: ?"
			]
		},
		options: [
			"15",
			"12",
			"14",
			"16"
		],
		correct: 0,
		explanation: "Se trata de la secuencia de números triangulares. Las diferencias entre términos son +2, +3, +4, +5. Por lo tanto, 10 + 5 = 15."
	},
	{
		id: "q12",
		category: "Lógica Numérica",
		question: "Resuelve el valor faltante: (3 [12] 4) | (5 [30] 6) | (7 [?] 8)",
		visual: { type: "mulBoxes" },
		options: [
			"56",
			"48",
			"64",
			"54"
		],
		correct: 0,
		explanation: "El valor central equivale a la multiplicación de los valores laterales: 7 × 8 = 56."
	},
	{
		id: "q13",
		category: "Patrones Visoespaciales",
		question: "Si giras una figura 180° en el sentido de las agujas del reloj, la parte superior izquierda termina en:",
		visual: { type: "rotate180" },
		options: [
			"Inferior derecha",
			"Inferior izquierda",
			"Superior derecha",
			"Queda en la misma posición"
		],
		correct: 0,
		explanation: "Una rotación de 180 grados invierte vertical y horizontalmente todas las posiciones: Superior-Izquierda pasa a Inferior-Derecha."
	},
	{
		id: "q14",
		category: "Razonamiento Verbal",
		question: "Encuentra la palabra que no pertenece al grupo:",
		visual: {
			type: "oddGroup",
			items: [
				"Mercurio",
				"Venus",
				"Luna",
				"Júpiter"
			]
		},
		options: [
			"Luna",
			"Mercurio",
			"Venus",
			"Júpiter"
		],
		correct: 0,
		explanation: "Mercurio, Venus y Júpiter son planetas del Sistema Solar. La Luna es un satélite natural."
	},
	{
		id: "q15",
		category: "Razonamiento Lógico",
		question: "Si ningún mamífero vuela y el murciélago es mamífero, ¿qué enunciado es correcto hipotéticamente?",
		visual: {
			type: "premises",
			lines: ["Premisa 1: Ningún mamífero vuela", "Premisa 2: El murciélago es mamífero"]
		},
		options: [
			"Bajo estas premisas, el murciélago no vuela",
			"El murciélago sí vuela",
			"Los pájaros son mamíferos",
			"Premisas contradictorias e inválidas"
		],
		correct: 0,
		explanation: "En lógica deductiva pura, siguiendo de forma estricta las premisas dadas, si ningún mamífero vuela y el murciélago es mamífero, la conclusión lógica es que el murciélago no vuela."
	},
	{
		id: "q16",
		category: "Razonamiento Espacial",
		question: "¿Cuál es la vista superior de un cilindro en posición vertical?",
		visual: { type: "cylinder" },
		options: [
			"Un Círculo",
			"Un Rectángulo",
			"Un Cuadrado",
			"Un Óvalo"
		],
		correct: 0,
		explanation: "Al observar un cilindro en vertical justo desde arriba, la proyección plana resultante es un círculo perfecto."
	},
	{
		id: "q17",
		category: "Lógica Numérica",
		question: "Completa el término que falta: 100, 95, 85, 70, 50, ___",
		visual: {
			type: "chips",
			items: [
				"100",
				"−5",
				"95",
				"−10",
				"85",
				"−15",
				"70",
				"−20",
				"50",
				"?"
			]
		},
		options: [
			"25",
			"30",
			"20",
			"35"
		],
		correct: 0,
		explanation: "La resta en cada paso se incrementa en 5 unidades: −5, −10, −15, −20, −25. Por tanto, 50 − 25 = 25."
	},
	{
		id: "q18",
		category: "Analogías Verbales",
		question: "AGUA es a SED como COMIDA es a:",
		visual: {
			type: "analogy",
			left: "AGUA",
			right: "SED",
			target: "COMIDA"
		},
		options: [
			"Hambre",
			"Restaurante",
			"Sabor",
			"Nutrición"
		],
		correct: 0,
		explanation: "El agua satisface la necesidad biológica de la sed, del mismo modo que la comida satisface el hambre."
	},
	{
		id: "q19",
		category: "Patrones Visoespaciales",
		question: "¿Qué color resulta de la mezcla luz RGB de Rojo y Verde a partes iguales?",
		visual: { type: "rgbMix" },
		options: [
			"Amarillo",
			"Azul",
			"Violeta",
			"Marrón"
		],
		correct: 0,
		explanation: "En la síntesis aditiva del modelo de color luz (RGB), la combinación de luz roja y luz verde genera luz amarilla."
	},
	{
		id: "q20",
		category: "Matrices Abstractas",
		question: "¿Qué número completa la matriz 3×3? [1, 2, 3] / [2, 4, 6] / [3, 6, ?]",
		visual: { type: "matrix3x3" },
		options: [
			"9",
			"8",
			"12",
			"7"
		],
		correct: 0,
		explanation: "Cada fila es el producto del número base de la columna por el índice de la fila. En la tercera fila: 3×1=3, 3×2=6, 3×3=9."
	},
	{
		id: "q21",
		category: "Razonamiento Lógico",
		question: "Si hoy es martes, ¿qué día de la semana será dentro de 15 días?",
		visual: { type: "weekday" },
		options: [
			"Miércoles",
			"Martes",
			"Jueves",
			"Lunes"
		],
		correct: 0,
		explanation: "15 días equivalen a 2 semanas completas (14 días) más 1 día extra. Por ende, un día después de martes es miércoles."
	},
	{
		id: "q22",
		category: "Memoria y Velocidad",
		question: "Escribe el resultado de: 15 + 25 × 2 − 10",
		visual: {
			type: "mathExpr",
			expr: "15 + (25 × 2) − 10"
		},
		options: [
			"55",
			"70",
			"65",
			"50"
		],
		correct: 0,
		explanation: "Siguiendo la jerarquía matemática de operaciones: primero se resuelve la multiplicación (25 × 2 = 50), luego la suma y la resta: 15 + 50 − 10 = 55."
	},
	{
		id: "q23",
		category: "Razonamiento Espacial",
		question: "Si desdoblas un cubo de cartón, ¿cuántas caras cuadradas posee en total?",
		visual: { type: "cubeNet" },
		options: [
			"6 caras",
			"4 caras",
			"8 caras",
			"5 caras"
		],
		correct: 0,
		explanation: "Un cubo geométrico tridimensional está compuesto exactamente por 6 caras cuadradas idénticas."
	},
	{
		id: "q24",
		category: "Lógica Numérica",
		question: "¿Cuál es el valor de X? 3, 6, 12, 24, X",
		visual: {
			type: "chips",
			items: [
				"3",
				"6",
				"12",
				"24",
				"X"
			]
		},
		options: [
			"48",
			"36",
			"42",
			"60"
		],
		correct: 0,
		explanation: "Cada término es el doble del anterior (× 2). Por lo tanto: 24 × 2 = 48."
	},
	{
		id: "q25",
		category: "Analogías Verbales",
		question: "PINTOR es a PINCEL como ESCULTOR es a:",
		visual: {
			type: "analogy",
			left: "PINTOR",
			right: "PINCEL",
			target: "ESCULTOR"
		},
		options: [
			"Cincel",
			"Mármol",
			"Estatua",
			"Lienzo"
		],
		correct: 0,
		explanation: "El pincel es la herramienta de trabajo principal del pintor, así como el cincel es la herramienta fundamental del escultor."
	}
];
var THEME_IDS = [
	"indigo",
	"emerald",
	"purple",
	"sunset",
	"ocean",
	"light"
];
var LB_KEY = "iq_app_leaderboard";
var HIST_KEY = "iq_app_history";
var THEME_KEY = "iq_app_theme";
var NAME_KEY = "iq_app_username";
function canUseStorage() {
	return typeof window !== "undefined";
}
function readJson(key, fallback) {
	if (!canUseStorage()) return fallback;
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
function loadLeaderboard() {
	const data = readJson(LB_KEY, []);
	return Array.isArray(data) ? data : [];
}
function saveLeaderboard(entries) {
	if (!canUseStorage()) return;
	localStorage.setItem(LB_KEY, JSON.stringify(entries));
}
function addLeaderboardEntry(entry) {
	const lb = [...loadLeaderboard(), entry];
	lb.sort((a, b) => {
		if (b.iq !== a.iq) return b.iq - a.iq;
		return a.timeSeconds - b.timeSeconds;
	});
	saveLeaderboard(lb);
	return {
		rank: lb.findIndex((item) => item === entry) + 1,
		total: lb.length
	};
}
function clearLeaderboard() {
	if (!canUseStorage()) return;
	localStorage.removeItem(LB_KEY);
}
function loadHistory() {
	const data = readJson(HIST_KEY, []);
	return Array.isArray(data) ? data : [];
}
function saveHistory(entries) {
	if (!canUseStorage()) return;
	localStorage.setItem(HIST_KEY, JSON.stringify(entries.slice(0, 40)));
}
function pushHistory(entry) {
	saveHistory([entry, ...loadHistory()]);
}
function clearHistoryStore() {
	if (!canUseStorage()) return;
	localStorage.removeItem(HIST_KEY);
}
function loadTheme() {
	if (!canUseStorage()) return "indigo";
	const id = (localStorage.getItem(THEME_KEY) ?? "indigo").replace("theme-", "");
	return THEME_IDS.includes(id) ? id : "indigo";
}
function saveTheme(id) {
	if (!canUseStorage()) return;
	localStorage.setItem(THEME_KEY, id);
}
function loadUsername() {
	if (!canUseStorage()) return "";
	return localStorage.getItem(NAME_KEY) ?? "";
}
function saveUsername(name) {
	if (!canUseStorage()) return;
	localStorage.setItem(NAME_KEY, name);
}
function prepareTest(length) {
	return shuffle(QUESTION_BANK).slice(0, length).map((q) => {
		const shuffled = shuffle(q.options.map((text, originalIdx) => ({
			text,
			originalIdx
		})));
		return {
			...q,
			options: shuffled.map((o) => o.text),
			originalCorrect: q.correct,
			correct: shuffled.findIndex((o) => o.originalIdx === q.correct)
		};
	});
}
function IqApp() {
	const [theme, setTheme] = (0, import_react.useState)("indigo");
	const [screen, setScreen] = (0, import_react.useState)("start");
	const [username, setUsername] = (0, import_react.useState)("");
	const [length, setLength] = (0, import_react.useState)(15);
	const [questions, setQuestions] = (0, import_react.useState)([]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const [flagged, setFlagged] = (0, import_react.useState)([]);
	const [seconds, setSeconds] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [results, setResults] = (0, import_react.useState)(null);
	const [leaderboard, setLeaderboard] = (0, import_react.useState)([]);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [reviewOpen, setReviewOpen] = (0, import_react.useState)(false);
	const [lbOpen, setLbOpen] = (0, import_react.useState)(false);
	const [histOpen, setHistOpen] = (0, import_react.useState)(false);
	const [gridOpen, setGridOpen] = (0, import_react.useState)(false);
	const [certOpen, setCertOpen] = (0, import_react.useState)(false);
	const [finishOpen, setFinishOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setTheme(loadTheme());
		setUsername(loadUsername());
		setLeaderboard(loadLeaderboard());
		setHistory(loadHistory());
	}, []);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		root.classList.toggle("dark", theme !== "light");
		for (const id of THEME_IDS) root.classList.remove(`theme-${id}`);
		root.classList.add(`theme-${theme}`);
	}, [theme]);
	(0, import_react.useEffect)(() => {
		if (screen !== "test" || paused) return;
		const id = window.setInterval(() => setSeconds((s) => s + 1), 1e3);
		return () => window.clearInterval(id);
	}, [screen, paused]);
	const changeTheme = (0, import_react.useCallback)((id) => {
		setTheme(id);
		saveTheme(id);
	}, []);
	const displayName = username.trim() || "Usuario Anónimo";
	const startTest = (0, import_react.useCallback)(() => {
		saveUsername(username.trim());
		const prepared = prepareTest(length);
		setQuestions(prepared);
		setIndex(0);
		setAnswers(new Array(prepared.length).fill(null));
		setFlagged(new Array(prepared.length).fill(false));
		setSeconds(0);
		setPaused(false);
		setResults(null);
		setReviewOpen(false);
		setScreen("test");
	}, [length, username]);
	const finishTest = (0, import_react.useCallback)(() => {
		const correct = countCorrect(questions, answers);
		const iq = computeIq(correct, questions.length, seconds);
		const classification = classifyIq(iq);
		const percentile = percentileFromIq(iq);
		const dateLabel = (/* @__PURE__ */ new Date()).toLocaleDateString("es-ES", {
			day: "2-digit",
			month: "long",
			year: "numeric"
		});
		const shortDate = (/* @__PURE__ */ new Date()).toLocaleDateString("es-ES", {
			day: "2-digit",
			month: "2-digit"
		});
		const { rank, total } = addLeaderboardEntry({
			name: displayName,
			iq,
			timeSeconds: seconds,
			date: shortDate
		});
		const payload = {
			iq,
			classification,
			correct,
			total: questions.length,
			seconds,
			accuracy: Math.round(correct / Math.max(questions.length, 1) * 100),
			percentile,
			rank,
			leaderboardSize: total,
			categories: categoryBreakdown(questions, answers),
			certCode: makeCertCode(),
			username: displayName,
			dateLabel
		};
		pushHistory({
			id: `${Date.now()}`,
			name: displayName,
			iq,
			classification,
			correct,
			total: questions.length,
			accuracy: payload.accuracy,
			seconds,
			percentile,
			date: dateLabel
		});
		setResults(payload);
		setLeaderboard(loadLeaderboard());
		setHistory(loadHistory());
		setPaused(true);
		setFinishOpen(false);
		setGridOpen(false);
		setScreen("results");
	}, [
		answers,
		displayName,
		questions,
		seconds
	]);
	const unanswered = (0, import_react.useMemo)(() => answers.filter((a) => a === null).length, [answers]);
	const goHome = (0, import_react.useCallback)(() => {
		setScreen("start");
		setPaused(true);
		setFinishOpen(false);
		setGridOpen(false);
		setCertOpen(false);
	}, []);
	const handleNext = (0, import_react.useCallback)(() => {
		if (index < questions.length - 1) {
			setIndex((i) => i + 1);
			return;
		}
		if (unanswered > 0) {
			setFinishOpen(true);
			return;
		}
		finishTest();
	}, [
		finishTest,
		index,
		questions.length,
		unanswered
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `theme-${theme} flex min-h-screen flex-col bg-background text-foreground`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {
				theme,
				onTheme: changeTheme,
				onHome: goHome,
				onLeaderboard: () => setLbOpen(true),
				onHistory: () => setHistOpen(true)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-4xl flex-grow items-center justify-center px-4 py-8",
				children: [
					screen === "start" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartScreen, {
						username,
						onUsername: setUsername,
						length,
						onLength: setLength,
						leaderboard,
						onOpenLeaderboard: () => setLbOpen(true),
						onStart: startTest
					}) : null,
					screen === "test" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScreen, {
						questions,
						index,
						answers,
						flagged,
						seconds,
						paused,
						onSelect: (opt) => setAnswers((prev) => {
							const next = [...prev];
							next[index] = opt;
							return next;
						}),
						onPrev: () => setIndex((i) => Math.max(0, i - 1)),
						onNext: handleNext,
						onFlag: () => setFlagged((prev) => {
							const next = [...prev];
							next[index] = !next[index];
							return next;
						}),
						onPause: () => setPaused((p) => !p),
						onOpenGrid: () => setGridOpen(true)
					}) : null,
					screen === "results" && results ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsScreen, {
						results,
						questions,
						answers,
						reviewOpen,
						onToggleReview: () => setReviewOpen((v) => !v),
						onLeaderboard: () => setLbOpen(true),
						onCertificate: () => setCertOpen(true),
						onRestart: goHome
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border bg-card py-4 text-center text-xs text-muted no-print",
				children: "© 2026 IQ Metrics Pro. Sistema dinámico de pruebas psicométricas adaptativas."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeaderboardModal, {
				open: lbOpen,
				onOpenChange: setLbOpen,
				entries: leaderboard,
				onReset: () => {
					clearLeaderboard();
					setLeaderboard([]);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryModal, {
				open: histOpen,
				onOpenChange: setHistOpen,
				entries: history,
				onClear: () => {
					clearHistoryStore();
					setHistory([]);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionGridModal, {
				open: gridOpen,
				onOpenChange: setGridOpen,
				questions,
				answers,
				flagged,
				index,
				onJump: (i) => {
					setIndex(i);
					setGridOpen(false);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinishConfirmModal, {
				open: finishOpen,
				onOpenChange: setFinishOpen,
				unanswered,
				onReview: () => {
					const first = answers.findIndex((a) => a === null);
					if (first >= 0) setIndex(first);
					setFinishOpen(false);
					setGridOpen(true);
				},
				onFinish: finishTest
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CertificateModal, {
				open: certOpen,
				onOpenChange: setCertOpen,
				results
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IqApp, {});
}
//#endregion
export { Home as component };
