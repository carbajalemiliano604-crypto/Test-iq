//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-t1QfvJYd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BhMRzqKX.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BhMRzqKX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CA-LJbF0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
