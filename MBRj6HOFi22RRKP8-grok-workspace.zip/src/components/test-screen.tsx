import { Bookmark, ChevronLeft, ChevronRight, Clock, LayoutGrid, Pause, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QuestionVisual } from "@/components/visuals";
import type { PreparedQuestion } from "@/lib/types";
import { cn, formatTime } from "@/lib/utils";

const LETTERS = ["A", "B", "C", "D"];

export function TestScreen({
  questions,
  index,
  answers,
  flagged,
  seconds,
  paused,
  onSelect,
  onPrev,
  onNext,
  onFlag,
  onPause,
  onOpenGrid,
}: {
  questions: PreparedQuestion[];
  index: number;
  answers: Array<number | null>;
  flagged: boolean[];
  seconds: number;
  paused: boolean;
  onSelect: (optionIndex: number) => void;
  onPrev: () => void;
  onNext: () => void;
  onFlag: () => void;
  onPause: () => void;
  onOpenGrid: () => void;
}) {
  const q = questions[index];
  if (!q) return null;
  const total = questions.length;
  const isLast = index === total - 1;
  const answered = answers.filter((a) => a !== null).length;
  const pct = ((index + 1) / total) * 100;

  return (
    <section className="w-full max-w-3xl space-y-6 rounded-3xl border border-border bg-card p-5 shadow-2xl md:p-8">
      <div className="flex flex-col items-center justify-between gap-4 border-b border-border pb-4 sm:flex-row">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-xl border border-primary/30 bg-primary/20 px-3 py-1.5 text-xs font-bold text-primary">
            Pregunta {index + 1}/{total}
          </span>
          <span className="rounded-xl border border-border bg-background px-3 py-1.5 text-xs font-medium text-muted">
            {q.category}
          </span>
          <button
            type="button"
            onClick={onFlag}
            className="rounded-lg border border-border p-2 text-muted hover:text-gold"
            title="Marcar para revisar"
            aria-label="Marcar para revisar"
          >
            <Bookmark
              className={cn("size-4", flagged[index] && "fill-gold text-gold")}
            />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-1.5">
            <Clock className="size-4 text-primary" />
            <span className="font-mono text-sm font-bold tabular-nums">{formatTime(seconds)}</span>
          </div>
          <Button
            variant="outline"
            size="icon-sm"
            onClick={onPause}
            className="rounded-xl bg-background"
            title={paused ? "Reanudar" : "Pausar"}
            aria-label={paused ? "Reanudar" : "Pausar"}
          >
            {paused ? <Play className="size-3.5 text-success" /> : <Pause className="size-3.5" />}
          </Button>
        </div>
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-background">
        <div
          className="h-full bg-primary transition-[width] duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>

      {paused ? (
        <div className="flex min-h-[220px] flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-background">
          <p className="text-lg font-bold">Evaluación en pausa</p>
          <p className="mt-1 text-sm text-muted">El cronómetro está detenido. Reanuda para continuar.</p>
          <Button className="mt-4" onClick={onPause}>
            <Play className="size-4" /> Reanudar
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          <h3 className="text-lg font-bold leading-snug text-foreground md:text-xl">{q.question}</h3>
          <QuestionVisual visual={q.visual} />
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {q.options.map((opt, idx) => {
              const selected = answers[index] === idx;
              return (
                <button
                  key={`${q.id}-${idx}`}
                  type="button"
                  onClick={() => onSelect(idx)}
                  className={cn(
                    "flex min-h-14 w-full items-center justify-between gap-3 rounded-2xl border p-4 text-left text-sm font-medium transition-colors",
                    selected
                      ? "border-primary bg-primary/10 text-foreground"
                      : "border-border bg-background text-foreground hover:border-primary",
                  )}
                >
                  <span>{opt}</span>
                  <span
                    className={cn(
                      "flex size-7 shrink-0 items-center justify-center rounded-lg border text-xs font-bold",
                      selected
                        ? "border-primary bg-primary text-on-primary"
                        : "border-border text-muted",
                    )}
                  >
                    {LETTERS[idx]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
        <Button variant="outline" onClick={onPrev} disabled={index === 0} className="rounded-xl bg-background">
          <ChevronLeft className="size-4" /> Anterior
        </Button>
        <button
          type="button"
          onClick={onOpenGrid}
          className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
        >
          <LayoutGrid className="size-3.5" /> Vista general ({answered})
        </button>
        <Button onClick={onNext} className="rounded-xl">
          {isLast ? "Finalizar" : "Siguiente"}
          <ChevronRight className="size-4" />
        </Button>
      </div>
    </section>
  );
}
