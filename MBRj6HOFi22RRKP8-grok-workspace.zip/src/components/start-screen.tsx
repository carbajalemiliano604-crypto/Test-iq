import { ArrowRight, Crown, Medal, SlidersHorizontal, Trophy, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { LeaderboardEntry, TestLength } from "@/lib/types";
import { cn } from "@/lib/utils";

const MODES: { value: TestLength; title: string; hint: string }[] = [
  { value: 10, title: "Rápido", hint: "10 preguntas" },
  { value: 15, title: "Estándar", hint: "15 preguntas" },
  { value: 25, title: "Exhaustivo", hint: "25 preguntas" },
];

function RankBadge({ index }: { index: number }) {
  if (index === 0) return <Trophy className="size-4 text-gold" />;
  if (index === 1) return <Medal className="size-4 text-muted" />;
  if (index === 2) return <Medal className="size-4 text-warning" />;
  return <span className="w-4 text-muted">#{index + 1}</span>;
}

export function StartScreen({
  username,
  onUsername,
  length,
  onLength,
  leaderboard,
  onOpenLeaderboard,
  onStart,
}: {
  username: string;
  onUsername: (v: string) => void;
  length: TestLength;
  onLength: (n: TestLength) => void;
  leaderboard: LeaderboardEntry[];
  onOpenLeaderboard: () => void;
  onStart: () => void;
}) {
  const top = leaderboard.slice(0, 3);

  return (
    <section className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-2xl md:p-10">
      <div className="relative z-10 space-y-6 text-center">
        <div>
          <h2 className="text-3xl font-extrabold tracking-tight text-foreground md:text-4xl">
            Test Adaptativo de Inteligencia
          </h2>
          <p className="mx-auto mt-2 max-w-lg text-sm text-muted md:text-base">
            Evaluación psicométrica completa. Preguntas barajadas, ranking competitivo y certificado
            oficial.
          </p>
        </div>

        <div className="space-y-2 rounded-2xl border border-border bg-background p-4 text-left">
          <label htmlFor="username-input" className="block text-xs font-bold uppercase tracking-wider text-muted">
            <User className="mr-1 inline size-3.5 text-primary" /> Tu nombre para la Tabla Top
          </label>
          <Input
            id="username-input"
            value={username}
            onChange={(e) => onUsername(e.target.value)}
            placeholder="Escribe tu nombre aquí..."
            autoComplete="nickname"
            maxLength={32}
          />
        </div>

        <div className="space-y-4 rounded-2xl border border-border bg-background p-4 text-left md:p-5">
          <p className="text-xs font-bold uppercase tracking-wider text-muted">
            <SlidersHorizontal className="mr-1 inline size-3.5 text-primary" /> Número de preguntas
          </p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {MODES.map((mode) => (
              <button
                key={mode.value}
                type="button"
                onClick={() => onLength(mode.value)}
                className={cn(
                  "rounded-xl border bg-card p-3.5 text-center transition-colors",
                  length === mode.value
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary",
                )}
              >
                <div className="text-sm font-bold text-foreground">{mode.title}</div>
                <div className="text-xs text-muted">{mode.hint}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3 rounded-2xl border border-border bg-background p-4">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-gold">
              <Crown className="size-3.5" /> Clasificación actual
            </span>
            <button
              type="button"
              onClick={onOpenLeaderboard}
              className="font-semibold text-primary hover:underline"
            >
              Ver todo
            </button>
          </div>
          <div className="space-y-1 text-xs">
            {top.length === 0 ? (
              <div className="py-4 text-center text-muted">
                <Trophy className="mx-auto mb-1 size-6 text-gold/40" />
                Aún no hay participantes. Sé el primero y toma el Top 1.
              </div>
            ) : (
              top.map((item, idx) => (
                <div
                  key={`${item.name}-${item.date}-${idx}`}
                  className="flex items-center justify-between rounded-xl border border-border bg-card p-2 font-semibold"
                >
                  <div className="flex items-center gap-2">
                    <RankBadge index={idx} />
                    <span className="text-foreground">{item.name}</span>
                  </div>
                  <span className="font-extrabold text-primary">{item.iq} CI</span>
                </div>
              ))
            )}
          </div>
        </div>

        <Button onClick={onStart} size="lg" className="h-14 w-full rounded-2xl text-lg shadow-lg">
          Iniciar Evaluación
          <ArrowRight className="size-5" />
        </Button>
      </div>
    </section>
  );
}
