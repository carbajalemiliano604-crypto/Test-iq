import {
  Award,
  CheckCircle2,
  Layers,
  ListChecks,
  RotateCcw,
  Trophy,
} from "lucide-react";
import { useEffect, useState } from "react";
import { GaussChart } from "@/components/gauss-chart";
import { Button } from "@/components/ui/button";
import { QuestionVisual } from "@/components/visuals";
import type { PreparedQuestion, TestResults } from "@/lib/types";
import { cn, formatTime } from "@/lib/utils";

function IqGauge({ iq }: { iq: number }) {
  const [shown, setShown] = useState(70);
  useEffect(() => {
    const start = performance.now();
    const from = 70;
    const dur = 700;
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur);
      setShown(Math.round(from + (iq - from) * t));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [iq]);

  const c = 2 * Math.PI * 42;
  const pct = (shown - 70) / 90;
  const offset = c * (1 - Math.min(1, Math.max(0, pct)));

  return (
    <div className="relative flex size-40 items-center justify-center">
      <svg className="size-full -rotate-90" viewBox="0 0 100 100">
        <circle
          cx="50"
          cy="50"
          r="42"
          stroke="currentColor"
          strokeWidth="8"
          className="text-border"
          fill="transparent"
        />
        <circle
          cx="50"
          cy="50"
          r="42"
          stroke="currentColor"
          strokeWidth="8"
          className="text-primary transition-[stroke-dashoffset] duration-700"
          fill="transparent"
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute text-center">
        <span className="block text-4xl font-black leading-none text-primary tabular-nums">
          {shown}
        </span>
        <span className="text-[10px] font-bold uppercase tracking-wider text-muted">
          Puntuación CI
        </span>
      </div>
    </div>
  );
}

export function ResultsScreen({
  results,
  questions,
  answers,
  reviewOpen,
  onToggleReview,
  onLeaderboard,
  onCertificate,
  onRestart,
}: {
  results: TestResults;
  questions: PreparedQuestion[];
  answers: Array<number | null>;
  reviewOpen: boolean;
  onToggleReview: () => void;
  onLeaderboard: () => void;
  onCertificate: () => void;
  onRestart: () => void;
}) {
  const podium =
    results.rank === 1
      ? "Nuevo récord. Ocupas el Top 1 de la tabla."
      : results.rank <= 3
        ? `Estás en el podio. Puesto #${results.rank}.`
        : results.rank <= 10
          ? `Entraste al Top 10. Puesto #${results.rank}.`
          : null;

  return (
    <section className="w-full max-w-4xl space-y-10 rounded-3xl border border-border bg-card p-6 shadow-2xl md:p-10">
      <div className="space-y-2 text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-success/20 bg-success/10 px-3 py-1 text-xs font-semibold text-success">
          <CheckCircle2 className="size-3.5" /> Evaluación completada
        </span>
        <h2 className="text-3xl font-extrabold text-foreground md:text-4xl">Tu perfil intelectual</h2>
        <p className="mx-auto max-w-xl text-xs text-muted md:text-sm">
          Resultado de CI calculado con ajuste psicométrico estandarizado y velocidad de respuesta.
        </p>
      </div>

      {podium ? (
        <div className="rounded-2xl border border-gold/40 bg-gold/10 p-4 text-center text-sm font-bold text-gold">
          {podium}
        </div>
      ) : null}

      <div className="grid grid-cols-1 items-center gap-6 rounded-2xl border border-border bg-background p-6 md:grid-cols-3">
        <div className="flex flex-col items-center justify-center md:border-r md:border-border md:pr-6">
          <IqGauge iq={results.iq} />
          <div className="mt-2 text-center text-sm font-bold text-primary">{results.classification}</div>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:col-span-2">
          <Stat label="Aciertos total" value={`${results.correct}/${results.total}`} tone="success" />
          <Stat label="Tiempo empleado" value={formatTime(results.seconds)} />
          <Stat label="Percentil global" value={`${results.percentile}%`} tone="secondary" />
          <Stat label="Puesto Top" value={`#${results.rank}`} tone="gold" />
          <Stat
            label="Precisión"
            value={`${results.accuracy}%`}
            tone="chart"
            className="col-span-2 sm:col-span-2"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <div className="flex flex-col justify-between rounded-2xl border border-border bg-background p-5">
          <div>
            <h4 className="mb-1 flex items-center gap-2 text-sm font-bold">
              <Layers className="size-4 text-primary" /> Curva normal de Gauss
            </h4>
            <p className="mb-3 text-xs text-muted">Tu ubicación dentro de la distribución poblacional.</p>
          </div>
          <GaussChart iq={results.iq} />
        </div>

        <div className="space-y-4 rounded-2xl border border-border bg-background p-5">
          <h4 className="flex items-center gap-2 text-sm font-bold">
            <Layers className="size-4 text-primary" /> Dominios cognitivos
          </h4>
          <div className="space-y-3">
            {results.categories.map((cat) => {
              const pct = cat.total ? Math.round((cat.correct / cat.total) * 100) : 0;
              return (
                <div key={cat.category}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="font-semibold">{cat.category}</span>
                    <span className="tabular-nums text-muted">
                      {cat.correct}/{cat.total} · {pct}%
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-card">
                    <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-3 no-print">
        <Button variant="gold" onClick={onLeaderboard}>
          <Trophy className="size-4" /> Ver Tabla Top
        </Button>
        <Button variant="outline" onClick={onToggleReview}>
          <ListChecks className="size-4 text-primary" /> Explicaciones paso a paso
        </Button>
        <Button variant="secondary" onClick={onCertificate}>
          <Award className="size-4" /> Certificado
        </Button>
        <Button onClick={onRestart}>
          <RotateCcw className="size-4" /> Nuevo test
        </Button>
      </div>

      {reviewOpen ? (
        <div className="space-y-4 border-t border-border pt-6">
          <h3 className="flex items-center gap-2 text-lg font-bold">
            <ListChecks className="size-5 text-primary" /> Solucionario detallado
          </h3>
          <div className="space-y-4">
            {questions.map((q, i) => {
              const chosen = answers[i];
              const ok = chosen === q.correct;
              return (
                <article key={q.id} className="space-y-3 rounded-2xl border border-border bg-background p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-bold">
                      {i + 1}. {q.question}
                    </p>
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase",
                        chosen === null
                          ? "bg-muted/20 text-muted"
                          : ok
                            ? "bg-success/15 text-success"
                            : "bg-danger/15 text-danger",
                      )}
                    >
                      {chosen === null ? "Sin respuesta" : ok ? "Correcta" : "Incorrecta"}
                    </span>
                  </div>
                  <QuestionVisual visual={q.visual} />
                  <ul className="grid gap-1.5 text-xs sm:grid-cols-2">
                    {q.options.map((opt, idx) => (
                      <li
                        key={opt}
                        className={cn(
                          "rounded-xl border px-3 py-2",
                          idx === q.correct
                            ? "border-success/40 bg-success/10"
                            : idx === chosen
                              ? "border-danger/40 bg-danger/10"
                              : "border-border",
                        )}
                      >
                        {opt}
                      </li>
                    ))}
                  </ul>
                  <p className="text-xs leading-relaxed text-muted">{q.explanation}</p>
                </article>
              );
            })}
          </div>
        </div>
      ) : null}
    </section>
  );
}

function Stat({
  label,
  value,
  tone,
  className,
}: {
  label: string;
  value: string;
  tone?: "success" | "secondary" | "gold" | "chart";
  className?: string;
}) {
  const color =
    tone === "success"
      ? "text-success"
      : tone === "secondary"
        ? "text-secondary"
        : tone === "gold"
          ? "text-gold"
          : tone === "chart"
            ? "text-chart"
            : "text-foreground";
  return (
    <div className={cn("rounded-2xl border border-border bg-card p-3.5", className)}>
      <span className="block text-xs text-muted">{label}</span>
      <span className={cn("text-xl font-extrabold tabular-nums", color)}>{value}</span>
    </div>
  );
}
