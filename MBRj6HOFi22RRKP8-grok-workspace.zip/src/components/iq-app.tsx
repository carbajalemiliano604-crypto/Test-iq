import { useCallback, useEffect, useMemo, useState } from "react";
import { AppHeader } from "@/components/app-header";
import {
  CertificateModal,
  FinishConfirmModal,
  HistoryModal,
  LeaderboardModal,
  QuestionGridModal,
} from "@/components/iq-modals";
import { ResultsScreen } from "@/components/results-screen";
import { StartScreen } from "@/components/start-screen";
import { TestScreen } from "@/components/test-screen";
import { QUESTION_BANK } from "@/lib/questions";
import {
  categoryBreakdown,
  classifyIq,
  computeIq,
  countCorrect,
  percentileFromIq,
} from "@/lib/scoring";
import {
  addLeaderboardEntry,
  clearHistoryStore,
  clearLeaderboard,
  loadHistory,
  loadLeaderboard,
  loadTheme,
  loadUsername,
  pushHistory,
  saveTheme,
  saveUsername,
} from "@/lib/storage";
import type {
  HistoryEntry,
  LeaderboardEntry,
  PreparedQuestion,
  Screen,
  TestLength,
  TestResults,
  ThemeId,
} from "@/lib/types";
import { THEME_IDS } from "@/lib/types";
import { makeCertCode, shuffle } from "@/lib/utils";

function prepareTest(length: TestLength): PreparedQuestion[] {
  return shuffle(QUESTION_BANK)
    .slice(0, length)
    .map((q) => {
      const withIndex = q.options.map((text, originalIdx) => ({ text, originalIdx }));
      const shuffled = shuffle(withIndex);
      return {
        ...q,
        options: shuffled.map((o) => o.text),
        originalCorrect: q.correct,
        correct: shuffled.findIndex((o) => o.originalIdx === q.correct),
      };
    });
}

export function IqApp() {
  const [theme, setTheme] = useState<ThemeId>("indigo");
  const [screen, setScreen] = useState<Screen>("start");
  const [username, setUsername] = useState("");
  const [length, setLength] = useState<TestLength>(15);
  const [questions, setQuestions] = useState<PreparedQuestion[]>([]);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Array<number | null>>([]);
  const [flagged, setFlagged] = useState<boolean[]>([]);
  const [seconds, setSeconds] = useState(0);
  const [paused, setPaused] = useState(false);
  const [results, setResults] = useState<TestResults | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [reviewOpen, setReviewOpen] = useState(false);

  const [lbOpen, setLbOpen] = useState(false);
  const [histOpen, setHistOpen] = useState(false);
  const [gridOpen, setGridOpen] = useState(false);
  const [certOpen, setCertOpen] = useState(false);
  const [finishOpen, setFinishOpen] = useState(false);

  useEffect(() => {
    setTheme(loadTheme());
    setUsername(loadUsername());
    setLeaderboard(loadLeaderboard());
    setHistory(loadHistory());
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme !== "light");
    for (const id of THEME_IDS) {
      root.classList.remove(`theme-${id}`);
    }
    root.classList.add(`theme-${theme}`);
  }, [theme]);

  useEffect(() => {
    if (screen !== "test" || paused) return;
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [screen, paused]);

  const changeTheme = useCallback((id: ThemeId) => {
    setTheme(id);
    saveTheme(id);
  }, []);

  const displayName = username.trim() || "Usuario Anónimo";

  const startTest = useCallback(() => {
    saveUsername(username.trim());
    const prepared = prepareTest(length);
    setQuestions(prepared);
    setIndex(0);
    setAnswers(new Array(prepared.length).fill(null));
    setFlagged(new Array(prepared.length).fill(false));
    setSeconds(0);
    setPaused(false);
    setResults(null);
    setReviewOpen(false);
    setScreen("test");
  }, [length, username]);

  const finishTest = useCallback(() => {
    const correct = countCorrect(questions, answers);
    const iq = computeIq(correct, questions.length, seconds);
    const classification = classifyIq(iq);
    const percentile = percentileFromIq(iq);
    const dateLabel = new Date().toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
    const shortDate = new Date().toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "2-digit",
    });
    const { rank, total } = addLeaderboardEntry({
      name: displayName,
      iq,
      timeSeconds: seconds,
      date: shortDate,
    });
    const payload: TestResults = {
      iq,
      classification,
      correct,
      total: questions.length,
      seconds,
      accuracy: Math.round((correct / Math.max(questions.length, 1)) * 100),
      percentile,
      rank,
      leaderboardSize: total,
      categories: categoryBreakdown(questions, answers),
      certCode: makeCertCode(),
      username: displayName,
      dateLabel,
    };
    pushHistory({
      id: `${Date.now()}`,
      name: displayName,
      iq,
      classification,
      correct,
      total: questions.length,
      accuracy: payload.accuracy,
      seconds,
      percentile,
      date: dateLabel,
    });
    setResults(payload);
    setLeaderboard(loadLeaderboard());
    setHistory(loadHistory());
    setPaused(true);
    setFinishOpen(false);
    setGridOpen(false);
    setScreen("results");
  }, [answers, displayName, questions, seconds]);

  const unanswered = useMemo(
    () => answers.filter((a) => a === null).length,
    [answers],
  );

  const goHome = useCallback(() => {
    setScreen("start");
    setPaused(true);
    setFinishOpen(false);
    setGridOpen(false);
    setCertOpen(false);
  }, []);

  const handleNext = useCallback(() => {
    if (index < questions.length - 1) {
      setIndex((i) => i + 1);
      return;
    }
    if (unanswered > 0) {
      setFinishOpen(true);
      return;
    }
    finishTest();
  }, [finishTest, index, questions.length, unanswered]);

  return (
    <div
      className={`theme-${theme} flex min-h-screen flex-col bg-background text-foreground`}
    >
      <AppHeader
        theme={theme}
        onTheme={changeTheme}
        onHome={goHome}
        onLeaderboard={() => setLbOpen(true)}
        onHistory={() => setHistOpen(true)}
      />

      <main className="mx-auto flex w-full max-w-4xl flex-grow items-center justify-center px-4 py-8">
        {screen === "start" ? (
          <StartScreen
            username={username}
            onUsername={setUsername}
            length={length}
            onLength={setLength}
            leaderboard={leaderboard}
            onOpenLeaderboard={() => setLbOpen(true)}
            onStart={startTest}
          />
        ) : null}
        {screen === "test" ? (
          <TestScreen
            questions={questions}
            index={index}
            answers={answers}
            flagged={flagged}
            seconds={seconds}
            paused={paused}
            onSelect={(opt) =>
              setAnswers((prev) => {
                const next = [...prev];
                next[index] = opt;
                return next;
              })
            }
            onPrev={() => setIndex((i) => Math.max(0, i - 1))}
            onNext={handleNext}
            onFlag={() =>
              setFlagged((prev) => {
                const next = [...prev];
                next[index] = !next[index];
                return next;
              })
            }
            onPause={() => setPaused((p) => !p)}
            onOpenGrid={() => setGridOpen(true)}
          />
        ) : null}
        {screen === "results" && results ? (
          <ResultsScreen
            results={results}
            questions={questions}
            answers={answers}
            reviewOpen={reviewOpen}
            onToggleReview={() => setReviewOpen((v) => !v)}
            onLeaderboard={() => setLbOpen(true)}
            onCertificate={() => setCertOpen(true)}
            onRestart={goHome}
          />
        ) : null}
      </main>

      <footer className="border-t border-border bg-card py-4 text-center text-xs text-muted no-print">
        © 2026 IQ Metrics Pro. Sistema dinámico de pruebas psicométricas adaptativas.
      </footer>

      <LeaderboardModal
        open={lbOpen}
        onOpenChange={setLbOpen}
        entries={leaderboard}
        onReset={() => {
          clearLeaderboard();
          setLeaderboard([]);
        }}
      />
      <HistoryModal
        open={histOpen}
        onOpenChange={setHistOpen}
        entries={history}
        onClear={() => {
          clearHistoryStore();
          setHistory([]);
        }}
      />
      <QuestionGridModal
        open={gridOpen}
        onOpenChange={setGridOpen}
        questions={questions}
        answers={answers}
        flagged={flagged}
        index={index}
        onJump={(i) => {
          setIndex(i);
          setGridOpen(false);
        }}
      />
      <FinishConfirmModal
        open={finishOpen}
        onOpenChange={setFinishOpen}
        unanswered={unanswered}
        onReview={() => {
          const first = answers.findIndex((a) => a === null);
          if (first >= 0) setIndex(first);
          setFinishOpen(false);
          setGridOpen(true);
        }}
        onFinish={finishTest}
      />
      <CertificateModal open={certOpen} onOpenChange={setCertOpen} results={results} />
    </div>
  );
}
