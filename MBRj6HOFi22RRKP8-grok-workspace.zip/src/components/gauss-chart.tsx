import { useMemo } from "react";
import {
  Area,
  AreaChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { gaussPoints } from "@/lib/scoring";

export function GaussChart({ iq }: { iq: number }) {
  const data = useMemo(() => gaussPoints(iq), [iq]);

  return (
    <div className="relative h-52 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="gaussFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.45} />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <XAxis
            dataKey="iq"
            tick={{ fill: "var(--color-muted)", fontSize: 10 }}
            tickLine={false}
            axisLine={false}
            ticks={[70, 85, 100, 115, 130, 145]}
          />
          <YAxis hide />
          <Tooltip
            contentStyle={{
              background: "var(--color-card)",
              border: "1px solid var(--color-border)",
              borderRadius: 12,
              fontSize: 12,
            }}
            formatter={(_value: number, _name: string, item) => {
              const point = item?.payload as { iq: number } | undefined;
              return [`CI ${point?.iq ?? ""}`, "Distribución"];
            }}
            labelFormatter={() => ""}
          />
          <Area
            type="monotone"
            dataKey="density"
            stroke="var(--color-chart)"
            strokeWidth={2}
            fill="url(#gaussFill)"
            isAnimationActive={false}
          />
          <ReferenceLine
            x={iq}
            stroke="var(--color-gold)"
            strokeWidth={2}
            strokeDasharray="4 3"
            label={{
              value: `Tú · ${iq}`,
              fill: "var(--color-gold)",
              fontSize: 11,
              fontWeight: 700,
              position: "top",
            }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
