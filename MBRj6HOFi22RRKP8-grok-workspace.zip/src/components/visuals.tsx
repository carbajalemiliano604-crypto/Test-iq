import type { ReactNode } from "react";
import type { VisualKind } from "@/lib/types";
import { cn } from "@/lib/utils";

function Frame({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "flex min-h-[180px] w-full items-center justify-center rounded-2xl border border-border bg-background p-4 md:p-6",
        className,
      )}
    >
      {children}
    </div>
  );
}

function Cell({
  children,
  missing,
}: {
  children?: React.ReactNode;
  missing?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex h-16 w-28 items-center justify-center rounded-lg border",
        missing
          ? "border-dashed border-primary"
          : "border-border bg-card",
      )}
    >
      {children}
    </div>
  );
}

function Matrix2x2() {
  return (
    <div className="grid grid-cols-2 gap-2">
      <Cell>
        <span className="size-8 rounded-full bg-primary" />
      </Cell>
      <Cell>
        <span className="relative size-8 rounded-full bg-primary">
          <span className="absolute left-1/2 top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-on-primary" />
        </span>
      </Cell>
      <Cell>
        <span className="size-8 rounded-sm bg-secondary" />
      </Cell>
      <Cell missing>
        <span className="text-xl font-bold text-primary">?</span>
      </Cell>
    </div>
  );
}

function Chips({ items }: { items: string[] }) {
  return (
    <div className="flex flex-wrap items-center justify-center gap-2 font-mono text-sm font-bold">
      {items.map((item, i) => {
        const isQ = item === "?" || item === "X" || item.endsWith("?");
        return (
          <span
            key={`${item}-${i}`}
            className={cn(
              "rounded-lg border px-2.5 py-1.5",
              isQ
                ? "border-primary bg-primary text-on-primary"
                : "border-border bg-card text-foreground",
            )}
          >
            {item}
          </span>
        );
      })}
    </div>
  );
}

function Premises({ lines }: { lines: string[] }) {
  return (
    <div className="w-full max-w-md space-y-1 rounded-xl border border-border bg-card px-4 py-3 text-center text-xs font-semibold">
      {lines.map((line) => (
        <p key={line} className="text-foreground">
          {line}
        </p>
      ))}
    </div>
  );
}

function Analogy({
  left,
  right,
  target,
}: {
  left: string;
  right: string;
  target: string;
}) {
  return (
    <p className="text-center text-sm font-bold tracking-wide text-foreground">
      {left} : {right} :: {target} : <span className="text-primary">?</span>
    </p>
  );
}

function ArrowIcon({ dir }: { dir: "right" | "down" | "left" | "up" }) {
  const rotate =
    dir === "right" ? "rotate-0" : dir === "down" ? "rotate-90" : dir === "left" ? "rotate-180" : "-rotate-90";
  return (
    <svg viewBox="0 0 48 48" className={cn("size-10 text-chart", rotate)}>
      <path
        d="M10 24h22M26 16l10 8-10 8"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function Arrows() {
  const dirs: Array<"right" | "down" | "left" | null> = ["right", "down", "left", null];
  return (
    <div className="flex flex-wrap items-center justify-center gap-2">
      {dirs.map((dir, i) => (
        <div
          key={i}
          className={cn(
            "flex size-16 items-center justify-center rounded-lg border bg-card",
            dir ? "border-border" : "border-dashed border-primary",
          )}
        >
          {dir ? <ArrowIcon dir={dir} /> : <span className="text-lg font-bold text-primary">?</span>}
        </div>
      ))}
    </div>
  );
}

function LetterShift() {
  return (
    <div className="rounded-xl border border-border bg-card px-5 py-4 text-center font-mono text-sm">
      <p>
        MENTE → <span className="font-bold text-primary">NFPUI</span>
      </p>
      <p className="mt-1">
        LOGICA → <span className="font-bold text-primary">?</span>
      </p>
    </div>
  );
}

function Pyramid() {
  return (
    <div className="space-y-2 text-center text-xs text-muted">
      <div className="flex flex-col items-center gap-1">
        <div className="size-5 rounded-sm bg-primary" />
        <div className="flex gap-1">
          <div className="size-5 rounded-sm bg-primary/80" />
          <div className="size-5 rounded-sm bg-primary/80" />
        </div>
        <div className="flex gap-1">
          <div className="size-5 rounded-sm bg-primary/60" />
          <div className="size-5 rounded-sm bg-primary/60" />
          <div className="size-5 rounded-sm bg-primary/60" />
        </div>
      </div>
      <div className="rounded-xl border border-border bg-card px-4 py-2">
        <p>Nivel 1 (base): 3×3 cubos</p>
        <p>Nivel 2 (centro): 2×2 cubos</p>
        <p>Nivel 3 (cúspide): 1×1 cubo</p>
      </div>
    </div>
  );
}

function Race() {
  return (
    <div className="w-full max-w-sm space-y-1 rounded-xl border border-border bg-card px-4 py-3 text-center text-xs font-semibold">
      <p>Daniel → Carlos → Beatriz</p>
      <p className="text-primary">Esteban → Daniel</p>
    </div>
  );
}

function MulBoxes() {
  return (
    <div className="space-y-1 rounded-xl border border-border bg-card px-5 py-3 text-center font-mono text-sm">
      <p>3 × 4 = 12</p>
      <p>5 × 6 = 30</p>
      <p className="font-bold text-primary">7 × 8 = ?</p>
    </div>
  );
}

function Rotate180() {
  return (
    <div className="flex items-center gap-4">
      <div className="grid grid-cols-2 gap-1">
        <div className="flex size-10 items-center justify-center rounded-md bg-primary text-[10px] font-bold text-on-primary">
          SI
        </div>
        <div className="size-10 rounded-md border border-border bg-card" />
        <div className="size-10 rounded-md border border-border bg-card" />
        <div className="size-10 rounded-md border border-border bg-card" />
      </div>
      <span className="text-xs font-bold text-muted">180°</span>
      <div className="grid grid-cols-2 gap-1">
        <div className="size-10 rounded-md border border-dashed border-primary" />
        <div className="size-10 rounded-md border border-border bg-card" />
        <div className="size-10 rounded-md border border-border bg-card" />
        <div className="flex size-10 items-center justify-center rounded-md border border-dashed border-primary text-sm font-bold text-primary">
          ?
        </div>
      </div>
    </div>
  );
}

function OddGroup({ items }: { items: string[] }) {
  return (
    <div className="flex flex-wrap justify-center gap-2">
      {items.map((item) => (
        <span
          key={item}
          className="rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold"
        >
          {item}
        </span>
      ))}
    </div>
  );
}

function Cylinder() {
  return (
    <div className="flex items-end gap-8">
      <svg viewBox="0 0 80 90" className="h-20 w-16 text-chart">
        <ellipse cx="40" cy="18" rx="28" ry="12" fill="currentColor" opacity="0.35" />
        <path
          d="M12 18 v50 a28 12 0 0 0 56 0 V18"
          fill="currentColor"
          opacity="0.2"
        />
        <ellipse cx="40" cy="18" rx="28" ry="12" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M12 18 v50" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M68 18 v50" fill="none" stroke="currentColor" strokeWidth="2" />
        <ellipse cx="40" cy="68" rx="28" ry="12" fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>
      <div className="text-center text-xs font-bold text-muted">
        Vista superior
        <div className="mt-2 flex size-12 items-center justify-center rounded-full border border-dashed border-primary text-primary">
          ?
        </div>
      </div>
    </div>
  );
}

function RgbMix() {
  return (
    <div className="flex items-center gap-3 text-xs font-bold">
      <span className="rounded-full bg-danger px-3 py-2 text-on-primary">Rojo</span>
      <span className="text-muted">+</span>
      <span className="rounded-full bg-success px-3 py-2 text-background">Verde</span>
      <span className="text-muted">=</span>
      <span className="rounded-full border border-dashed border-primary px-3 py-2 text-primary">?</span>
    </div>
  );
}

function Matrix3x3() {
  const cells = ["1", "2", "3", "2", "4", "6", "3", "6", "?"];
  return (
    <div className="grid grid-cols-3 gap-1.5 font-mono text-sm font-bold">
      {cells.map((c, i) => (
        <div
          key={i}
          className={cn(
            "flex size-12 items-center justify-center rounded-lg border",
            c === "?"
              ? "border-primary bg-primary text-on-primary"
              : "border-border bg-card",
          )}
        >
          {c}
        </div>
      ))}
    </div>
  );
}

function Weekday() {
  return (
    <div className="rounded-xl border border-border bg-card px-5 py-3 text-center text-xs font-bold">
      Hoy = Martes
      <p className="mt-1 text-primary">¿Día en +15 días?</p>
    </div>
  );
}

function MathExpr({ expr }: { expr: string }) {
  return (
    <p className="rounded-xl border border-border bg-card px-5 py-3 font-mono text-sm font-bold">
      {expr} = <span className="text-primary">?</span>
    </p>
  );
}

function CubeNet() {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="size-8 rounded-sm border border-border bg-primary/30" />
      <div className="flex gap-1">
        <div className="size-8 rounded-sm border border-border bg-primary/40" />
        <div className="size-8 rounded-sm border border-border bg-primary/70" />
        <div className="size-8 rounded-sm border border-border bg-primary/40" />
        <div className="size-8 rounded-sm border border-border bg-primary/40" />
      </div>
      <div className="size-8 rounded-sm border border-border bg-primary/30" />
    </div>
  );
}

function Note({ title, body }: { title: string; body: string }) {
  return (
    <div className="max-w-md rounded-xl border border-border bg-card px-4 py-3 text-center text-xs">
      <p className="font-bold text-primary">{title}</p>
      <p className="mt-1 text-muted">{body}</p>
    </div>
  );
}

export function QuestionVisual({ visual }: { visual: VisualKind }) {
  let inner: ReactNode;
  switch (visual.type) {
    case "matrix2x2":
      inner = <Matrix2x2 />;
      break;
    case "chips":
      inner = <Chips items={visual.items} />;
      break;
    case "premises":
      inner = <Premises lines={visual.lines} />;
      break;
    case "analogy":
      inner = <Analogy left={visual.left} right={visual.right} target={visual.target} />;
      break;
    case "arrows":
      inner = <Arrows />;
      break;
    case "letterShift":
      inner = <LetterShift />;
      break;
    case "pyramid":
      inner = <Pyramid />;
      break;
    case "race":
      inner = <Race />;
      break;
    case "mulBoxes":
      inner = <MulBoxes />;
      break;
    case "rotate180":
      inner = <Rotate180 />;
      break;
    case "oddGroup":
      inner = <OddGroup items={visual.items} />;
      break;
    case "cylinder":
      inner = <Cylinder />;
      break;
    case "rgbMix":
      inner = <RgbMix />;
      break;
    case "matrix3x3":
      inner = <Matrix3x3 />;
      break;
    case "weekday":
      inner = <Weekday />;
      break;
    case "mathExpr":
      inner = <MathExpr expr={visual.expr} />;
      break;
    case "cubeNet":
      inner = <CubeNet />;
      break;
    case "note":
      inner = <Note title={visual.title} body={visual.body} />;
      break;
    default:
      inner = null;
  }
  return <Frame>{inner}</Frame>;
}
