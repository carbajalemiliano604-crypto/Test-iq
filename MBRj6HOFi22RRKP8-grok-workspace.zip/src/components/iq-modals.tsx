import { Award, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { HistoryEntry, LeaderboardEntry, PreparedQuestion, TestResults } from "@/lib/types";
import { cn, formatTime } from "@/lib/utils";

export function LeaderboardModal({
  open,
  onOpenChange,
  entries,
  onReset,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entries: LeaderboardEntry[];
  onReset: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="size-5 text-gold" /> Tabla Top de CI
          </DialogTitle>
          <DialogDescription>
            Clasificación en tiempo real. Los lugares se mueven según la puntuación de CI y la
            velocidad de resolución.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-80 space-y-2 overflow-y-auto pr-1 text-xs">
          {entries.length === 0 ? (
            <div className="py-8 text-center text-muted">
              <Trophy className="mx-auto mb-2 size-8 text-gold/40" />
              <p className="font-bold">La Tabla Top está vacía</p>
              <p className="mt-1 text-[11px]">Completa una evaluación para registrar tu puntuación.</p>
            </div>
          ) : (
            entries.map((item, idx) => (
              <div
                key={`${item.name}-${item.date}-${idx}`}
                className={cn(
                  "flex items-center justify-between rounded-2xl border p-3",
                  idx === 0
                    ? "border-gold/40 bg-gold/10 text-gold"
                    : idx === 1
                      ? "border-border bg-background"
                      : idx === 2
                        ? "border-warning/30 bg-warning/10 text-warning"
                        : "border-border bg-background",
                )}
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 text-center text-sm font-extrabold">{idx + 1}</span>
                  <div>
                    <div className="text-sm font-bold">{item.name}</div>
                    <div className="text-[10px] opacity-70">
                      {item.date} · {formatTime(item.timeSeconds)} min
                    </div>
                  </div>
                </div>
                <div className="text-base font-black text-primary">
                  {item.iq}{" "}
                  <span className="text-[10px] font-normal text-muted">CI</span>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="flex items-center justify-between border-t border-border pt-3">
          <button type="button" onClick={onReset} className="text-[11px] text-danger hover:underline">
            Vaciar Tabla Top
          </button>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function HistoryModal({
  open,
  onOpenChange,
  entries,
  onClear,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entries: HistoryEntry[];
  onClear: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Historial de intentos</DialogTitle>
        </DialogHeader>
        <div className="max-h-72 space-y-2 overflow-y-auto text-xs">
          {entries.length === 0 ? (
            <p className="py-8 text-center text-muted">Todavía no hay intentos guardados.</p>
          ) : (
            entries.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-2xl border border-border bg-background p-3"
              >
                <div>
                  <p className="font-bold">{item.name}</p>
                  <p className="text-[10px] text-muted">
                    {item.date} · {item.correct}/{item.total} · {formatTime(item.seconds)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-base font-black text-primary">{item.iq} CI</p>
                  <p className="text-[10px] text-muted">{item.classification}</p>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="flex items-center justify-between pt-2">
          <button type="button" onClick={onClear} className="text-xs text-danger hover:underline">
            Limpiar historial
          </button>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function QuestionGridModal({
  open,
  onOpenChange,
  questions,
  answers,
  flagged,
  index,
  onJump,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  questions: PreparedQuestion[];
  answers: Array<number | null>;
  flagged: boolean[];
  index: number;
  onJump: (i: number) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Mapa del test</DialogTitle>
        </DialogHeader>
        <div className="grid max-h-60 grid-cols-5 gap-2 overflow-y-auto p-1">
          {questions.map((q, i) => {
            const answered = answers[i] !== null;
            const isCurrent = i === index;
            return (
              <button
                key={q.id}
                type="button"
                onClick={() => onJump(i)}
                className={cn(
                  "flex h-11 items-center justify-center rounded-xl border text-xs font-bold",
                  isCurrent
                    ? "border-primary bg-primary text-on-primary"
                    : flagged[i]
                      ? "border-gold bg-gold/15 text-gold"
                      : answered
                        ? "border-primary/40 bg-primary/10 text-primary"
                        : "border-border bg-background",
                )}
              >
                {i + 1}
              </button>
            );
          })}
        </div>
        <Button variant="outline" className="w-full" onClick={() => onOpenChange(false)}>
          Cerrar
        </Button>
      </DialogContent>
    </Dialog>
  );
}

export function FinishConfirmModal({
  open,
  onOpenChange,
  unanswered,
  onReview,
  onFinish,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  unanswered: number;
  onReview: () => void;
  onFinish: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Hay preguntas sin responder</DialogTitle>
          <DialogDescription>
            Quedan {unanswered} {unanswered === 1 ? "pregunta" : "preguntas"} en blanco. Puedes
            revisarlas o enviar el test ahora.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
          <Button variant="outline" onClick={onReview}>
            Revisar
          </Button>
          <Button onClick={onFinish}>Enviar de todos modos</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function CertificateModal({
  open,
  onOpenChange,
  results,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  results: TestResults | null;
}) {
  if (!results) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="print-area max-w-2xl space-y-6 bg-card p-8 text-center"
        showClose
      >
        <DialogHeader className="border-b border-border pb-4">
          <Award className="mx-auto mb-2 size-12 text-primary" />
          <DialogTitle className="text-2xl font-extrabold uppercase tracking-widest text-primary">
            Certificado Oficial de Desempeño
          </DialogTitle>
          <DialogDescription>IQ METRICS PSYCHOMETRIC EVALUATION</DialogDescription>
        </DialogHeader>
        <p className="text-sm text-muted">
          Se certifica que{" "}
          <strong className="text-primary">{results.username}</strong> ha completado la
          evaluación psicométrica estandarizada obteniendo:
        </p>
        <div className="inline-block rounded-2xl border border-primary/30 bg-background px-8 py-4">
          <span className="block text-xs font-semibold uppercase text-muted">
            Coeficiente intelectual estimado
          </span>
          <span className="text-5xl font-black text-primary tabular-nums">{results.iq}</span>
          <span className="mt-1 block text-sm font-bold">{results.classification}</span>
        </div>
        <div className="mx-auto grid max-w-md grid-cols-2 gap-4 pt-2 text-left text-xs">
          <div className="rounded-xl border border-border bg-background p-3">
            <span className="block text-muted">Fecha de emisión</span>
            <strong>{results.dateLabel}</strong>
          </div>
          <div className="rounded-xl border border-border bg-background p-3">
            <span className="block text-muted">Código de verificación</span>
            <strong className="font-mono">{results.certCode}</strong>
          </div>
        </div>
        <div className="flex justify-center gap-3 pt-2 no-print">
          <Button onClick={() => window.print()}>Imprimir / Guardar en PDF</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
