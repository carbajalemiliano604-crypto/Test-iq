import { Clock3, Palette, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { THEME_META } from "@/lib/themes";
import type { ThemeId } from "@/lib/types";
import { cn } from "@/lib/utils";

export function AppHeader({
  theme,
  onTheme,
  onHome,
  onLeaderboard,
  onHistory,
}: {
  theme: ThemeId;
  onTheme: (id: ThemeId) => void;
  onHome: () => void;
  onLeaderboard: () => void;
  onHistory: () => void;
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-card/85 backdrop-blur-md no-print">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <button type="button" onClick={onHome} className="text-left">
          <h1 className="text-xl font-black tracking-wider text-foreground">IQ Metrics Pro</h1>
          <span className="block text-[10px] font-bold uppercase tracking-widest text-muted">
            Evaluación Psicométrica Estandarizada
          </span>
        </button>

        <div className="flex items-center gap-2 sm:gap-3">
          <Button variant="gold" size="sm" onClick={onLeaderboard} className="rounded-xl">
            <Trophy className="size-4" />
            <span className="hidden sm:inline">Tabla Top</span>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="rounded-xl bg-background">
                <Palette className="size-4 text-primary" />
                <span className="hidden sm:inline">Tema</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Elegir esquema</DropdownMenuLabel>
              {THEME_META.map((item) => (
                <DropdownMenuItem key={item.id} onSelect={() => onTheme(item.id)}>
                  <span className={cn(theme === item.id && "text-primary")}>{item.label}</span>
                  <span className={cn("size-3 rounded-full", item.swatch)} />
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="outline" size="sm" onClick={onHistory} className="rounded-xl bg-background">
            <Clock3 className="size-4 text-primary" />
            <span className="hidden sm:inline">Historial</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
