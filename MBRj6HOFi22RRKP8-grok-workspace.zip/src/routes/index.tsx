import { createFileRoute } from "@tanstack/react-router";
import { IqApp } from "@/components/iq-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <IqApp />;
}
