import type { CategoryScore, PreparedQuestion } from "./types";

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;
  const t = 1 / (1 + p * ax);
  const y =
    1 -
    ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-ax * ax);
  return sign * y;
}

export function classifyIq(iq: number): string {
  if (iq >= 145) return "Genio";
  if (iq >= 130) return "Muy superior";
  if (iq >= 120) return "Superior";
  if (iq >= 110) return "Por encima del promedio";
  if (iq >= 90) return "Promedio";
  if (iq >= 80) return "Por debajo del promedio";
  return "Límite";
}

export function percentileFromIq(iq: number): number {
  const z = (iq - 100) / 15;
  const p = 0.5 * (1 + erf(z / Math.SQRT2));
  return Math.round(clamp(p * 100, 1, 99));
}

/** Standardized estimate: accuracy maps to ~70–142, speed trims ±12. */
export function computeIq(correct: number, total: number, seconds: number): number {
  const accuracy = total === 0 ? 0 : correct / total;
  const base = 70 + accuracy * 72;
  const avg = seconds / Math.max(total, 1);
  let adj = 0;
  if (accuracy >= 0.45) {
    if (avg < 10) adj = 12;
    else if (avg < 16) adj = 7;
    else if (avg < 24) adj = 3;
    else if (avg > 55) adj = -8;
    else if (avg > 40) adj = -4;
  } else if (avg > 50) {
    adj = -4;
  }
  return Math.round(clamp(base + adj, 70, 160));
}

export function countCorrect(
  questions: PreparedQuestion[],
  answers: Array<number | null>,
): number {
  return questions.reduce((sum, q, i) => {
    return sum + (answers[i] === q.correct ? 1 : 0);
  }, 0);
}

export function categoryBreakdown(
  questions: PreparedQuestion[],
  answers: Array<number | null>,
): CategoryScore[] {
  const map = new Map<string, CategoryScore>();
  questions.forEach((q, i) => {
    const row = map.get(q.category) ?? {
      category: q.category,
      correct: 0,
      total: 0,
    };
    row.total += 1;
    if (answers[i] === q.correct) row.correct += 1;
    map.set(q.category, row);
  });
  return [...map.values()].sort((a, b) => b.total - a.total);
}

export function gaussPoints(userIq: number) {
  const pts: { iq: number; density: number; user: number | null }[] = [];
  for (let x = 55; x <= 145; x += 1) {
    const density = Math.exp(-0.5 * ((x - 100) / 15) ** 2);
    pts.push({
      iq: x,
      density,
      user: x === Math.round(clamp(userIq, 55, 145)) ? density : null,
    });
  }
  return pts;
}
