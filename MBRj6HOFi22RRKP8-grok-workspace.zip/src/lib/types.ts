export const THEME_IDS = [
  "indigo",
  "emerald",
  "purple",
  "sunset",
  "ocean",
  "light",
] as const;

export type ThemeId = (typeof THEME_IDS)[number];

export type TestLength = 10 | 15 | 25;

export type Screen = "start" | "test" | "results";

export type VisualKind =
  | { type: "matrix2x2" }
  | { type: "chips"; items: string[] }
  | { type: "premises"; lines: string[] }
  | { type: "analogy"; left: string; right: string; target: string }
  | { type: "arrows" }
  | { type: "letterShift" }
  | { type: "pyramid" }
  | { type: "race" }
  | { type: "mulBoxes" }
  | { type: "rotate180" }
  | { type: "oddGroup"; items: string[] }
  | { type: "cylinder" }
  | { type: "rgbMix" }
  | { type: "matrix3x3" }
  | { type: "weekday" }
  | { type: "mathExpr"; expr: string }
  | { type: "cubeNet" }
  | { type: "note"; title: string; body: string };

export interface Question {
  id: string;
  category: string;
  question: string;
  visual: VisualKind;
  options: string[];
  correct: number;
  explanation: string;
}

export interface PreparedQuestion extends Question {
  originalCorrect: number;
}

export interface LeaderboardEntry {
  name: string;
  iq: number;
  timeSeconds: number;
  date: string;
}

export interface HistoryEntry {
  id: string;
  name: string;
  iq: number;
  classification: string;
  correct: number;
  total: number;
  accuracy: number;
  seconds: number;
  percentile: number;
  date: string;
}

export interface CategoryScore {
  category: string;
  correct: number;
  total: number;
}

export interface TestResults {
  iq: number;
  classification: string;
  correct: number;
  total: number;
  seconds: number;
  accuracy: number;
  percentile: number;
  rank: number;
  leaderboardSize: number;
  categories: CategoryScore[];
  certCode: string;
  username: string;
  dateLabel: string;
}
