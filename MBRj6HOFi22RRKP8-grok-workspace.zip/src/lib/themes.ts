import type { ThemeId } from "./types";

export const THEME_META: { id: ThemeId; label: string; swatch: string }[] = [
  { id: "indigo", label: "Neon Indigo", swatch: "swatch-indigo" },
  { id: "emerald", label: "Cyber Emerald", swatch: "swatch-emerald" },
  { id: "purple", label: "Royal Purple", swatch: "swatch-purple" },
  { id: "sunset", label: "Sunset Amber", swatch: "swatch-sunset" },
  { id: "ocean", label: "Ocean Deep", swatch: "swatch-ocean" },
  { id: "light", label: "Modo Claro", swatch: "swatch-light" },
];
