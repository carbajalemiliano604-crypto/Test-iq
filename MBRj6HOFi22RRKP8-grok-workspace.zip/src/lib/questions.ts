import type { Question } from "./types";

export const QUESTION_BANK: Question[] = [
  {
    id: "q1",
    category: "Razonamiento Espacial",
    question: "¿Qué figura completa lógicamente la matriz 2×2?",
    visual: { type: "matrix2x2" },
    options: [
      "Cuadrado púrpura con punto blanco central",
      "Círculo azul con cuadrado central",
      "Cuadrado púrpura totalmente vacío",
      "Triángulo púrpura con punto central",
    ],
    correct: 0,
    explanation:
      "En la fila superior, la figura añade un punto blanco central en la casilla derecha. Por analogía, el cuadrado púrpura debe mantener su figura e incorporar el punto blanco central.",
  },
  {
    id: "q2",
    category: "Lógica Numérica",
    question: "Determina el número faltante en la serie: 4, 9, 19, 39, 79, ___",
    visual: { type: "chips", items: ["4", "9", "19", "39", "79", "?"] },
    options: ["159", "149", "158", "169"],
    correct: 0,
    explanation:
      "La regla de progresión es duplicar el valor previo y sumar 1 (×2 + 1). Así: 79 × 2 + 1 = 159.",
  },
  {
    id: "q3",
    category: "Razonamiento Lógico",
    question:
      "Si todo A es B, y ningún B es C, ¿cuál es la única deducción formalmente válida?",
    visual: {
      type: "premises",
      lines: ["Premisa 1: Todo [A] pertenece a [B]", "Premisa 2: Ningún [B] pertenece a [C]"],
    },
    options: [
      "Ningún A es C",
      "Algunos A son C",
      "Todo C es A",
      "Ninguna de las anteriores",
    ],
    correct: 0,
    explanation:
      "Dado que A está completamente contenido dentro del conjunto B, y B está totalmente excluido de C, resulta imposible que algún A pertenezca a C.",
  },
  {
    id: "q4",
    category: "Analogías Verbales",
    question: "TELESCOPIO es a ESTRELLA como MICROSCOPIO es a:",
    visual: {
      type: "analogy",
      left: "TELESCOPIO",
      right: "ESTRELLA",
      target: "MICROSCOPIO",
    },
    options: ["Célula / Bacteria", "Lente", "Laboratorio", "Planeta"],
    correct: 0,
    explanation:
      "El telescopio es una herramienta diseñada para observar objetos lejanos (estrellas), mientras que el microscopio se utiliza para observar estructuras microscópicas (células).",
  },
  {
    id: "q5",
    category: "Patrones Visoespaciales",
    question: "¿Hacia dónde apunta la flecha en la cuarta etapa de la secuencia?",
    visual: { type: "arrows" },
    options: [
      "Hacia arriba (↑)",
      "Hacia abajo (↓)",
      "Hacia la derecha (→)",
      "Hacia la izquierda (←)",
    ],
    correct: 0,
    explanation:
      "La flecha rota 90 grados en sentido horario en cada paso: Derecha → Abajo → Izquierda → Arriba.",
  },
  {
    id: "q6",
    category: "Lógica Numérica",
    question: "¿Qué número reemplaza el signo de interrogación? 2, 3, 5, 7, 11, 13, ___",
    visual: { type: "chips", items: ["2", "3", "5", "7", "11", "13", "?"] },
    options: ["17", "15", "19", "21"],
    correct: 0,
    explanation:
      "Es la serie de números primos en orden ascendente. El número primo sucesor de 13 es 17.",
  },
  {
    id: "q7",
    category: "Memoria y Velocidad",
    question:
      "Si «MENTE» se transforma en «NFPUI» (desplazando +1 cada letra), ¿cómo se transforma «LOGICA»?",
    visual: { type: "letterShift" },
    options: ["MPHJDB", "MOHJDB", "NPHJDC", "LOHJDB"],
    correct: 0,
    explanation:
      "Avanzando cada carácter un puesto en el alfabeto: L→M, O→P, G→H, I→J, C→D, A→B. Resultado: MPHJDB.",
  },
  {
    id: "q8",
    category: "Razonamiento Espacial",
    question: "¿Cuántos cubos individuales forman una pirámide cuadrada de base 3×3?",
    visual: { type: "pyramid" },
    options: ["14 cubos", "12 cubos", "10 cubos", "15 cubos"],
    correct: 0,
    explanation:
      "Sumando los bloques por cada nivel: 3² + 2² + 1² = 9 + 4 + 1 = 14 cubos.",
  },
  {
    id: "q9",
    category: "Analogías Verbales",
    question: "BRÚJULA es a ORIENTACIÓN como RELOJ es a:",
    visual: {
      type: "analogy",
      left: "BRÚJULA",
      right: "ORIENTACIÓN",
      target: "RELOJ",
    },
    options: ["Medición del Tiempo", "Segundos", "Muñeca", "Alarma"],
    correct: 0,
    explanation:
      "La brújula mide/indica la orientación, mientras que el reloj mide el tiempo.",
  },
  {
    id: "q10",
    category: "Razonamiento Lógico",
    question:
      "En una competencia, Carlos llegó antes que Beatriz, pero después de Daniel. Esteban llegó antes que Daniel. ¿Quién ganó la carrera?",
    visual: { type: "race" },
    options: ["Esteban", "Daniel", "Carlos", "Beatriz"],
    correct: 0,
    explanation:
      "El orden completo de llegada es: Esteban > Daniel > Carlos > Beatriz. El ganador es Esteban.",
  },
  {
    id: "q11",
    category: "Matrices Abstractas",
    question:
      "¿Qué cantidad de elementos debe tener la quinta figura según el patrón: 1, 3, 6, 10, ___?",
    visual: { type: "chips", items: ["F1: 1", "F2: 3", "F3: 6", "F4: 10", "F5: ?"] },
    options: ["15", "12", "14", "16"],
    correct: 0,
    explanation:
      "Se trata de la secuencia de números triangulares. Las diferencias entre términos son +2, +3, +4, +5. Por lo tanto, 10 + 5 = 15.",
  },
  {
    id: "q12",
    category: "Lógica Numérica",
    question: "Resuelve el valor faltante: (3 [12] 4) | (5 [30] 6) | (7 [?] 8)",
    visual: { type: "mulBoxes" },
    options: ["56", "48", "64", "54"],
    correct: 0,
    explanation:
      "El valor central equivale a la multiplicación de los valores laterales: 7 × 8 = 56.",
  },
  {
    id: "q13",
    category: "Patrones Visoespaciales",
    question:
      "Si giras una figura 180° en el sentido de las agujas del reloj, la parte superior izquierda termina en:",
    visual: { type: "rotate180" },
    options: [
      "Inferior derecha",
      "Inferior izquierda",
      "Superior derecha",
      "Queda en la misma posición",
    ],
    correct: 0,
    explanation:
      "Una rotación de 180 grados invierte vertical y horizontalmente todas las posiciones: Superior-Izquierda pasa a Inferior-Derecha.",
  },
  {
    id: "q14",
    category: "Razonamiento Verbal",
    question: "Encuentra la palabra que no pertenece al grupo:",
    visual: {
      type: "oddGroup",
      items: ["Mercurio", "Venus", "Luna", "Júpiter"],
    },
    options: ["Luna", "Mercurio", "Venus", "Júpiter"],
    correct: 0,
    explanation:
      "Mercurio, Venus y Júpiter son planetas del Sistema Solar. La Luna es un satélite natural.",
  },
  {
    id: "q15",
    category: "Razonamiento Lógico",
    question:
      "Si ningún mamífero vuela y el murciélago es mamífero, ¿qué enunciado es correcto hipotéticamente?",
    visual: {
      type: "premises",
      lines: [
        "Premisa 1: Ningún mamífero vuela",
        "Premisa 2: El murciélago es mamífero",
      ],
    },
    options: [
      "Bajo estas premisas, el murciélago no vuela",
      "El murciélago sí vuela",
      "Los pájaros son mamíferos",
      "Premisas contradictorias e inválidas",
    ],
    correct: 0,
    explanation:
      "En lógica deductiva pura, siguiendo de forma estricta las premisas dadas, si ningún mamífero vuela y el murciélago es mamífero, la conclusión lógica es que el murciélago no vuela.",
  },
  {
    id: "q16",
    category: "Razonamiento Espacial",
    question: "¿Cuál es la vista superior de un cilindro en posición vertical?",
    visual: { type: "cylinder" },
    options: ["Un Círculo", "Un Rectángulo", "Un Cuadrado", "Un Óvalo"],
    correct: 0,
    explanation:
      "Al observar un cilindro en vertical justo desde arriba, la proyección plana resultante es un círculo perfecto.",
  },
  {
    id: "q17",
    category: "Lógica Numérica",
    question: "Completa el término que falta: 100, 95, 85, 70, 50, ___",
    visual: { type: "chips", items: ["100", "−5", "95", "−10", "85", "−15", "70", "−20", "50", "?"] },
    options: ["25", "30", "20", "35"],
    correct: 0,
    explanation:
      "La resta en cada paso se incrementa en 5 unidades: −5, −10, −15, −20, −25. Por tanto, 50 − 25 = 25.",
  },
  {
    id: "q18",
    category: "Analogías Verbales",
    question: "AGUA es a SED como COMIDA es a:",
    visual: { type: "analogy", left: "AGUA", right: "SED", target: "COMIDA" },
    options: ["Hambre", "Restaurante", "Sabor", "Nutrición"],
    correct: 0,
    explanation:
      "El agua satisface la necesidad biológica de la sed, del mismo modo que la comida satisface el hambre.",
  },
  {
    id: "q19",
    category: "Patrones Visoespaciales",
    question: "¿Qué color resulta de la mezcla luz RGB de Rojo y Verde a partes iguales?",
    visual: { type: "rgbMix" },
    options: ["Amarillo", "Azul", "Violeta", "Marrón"],
    correct: 0,
    explanation:
      "En la síntesis aditiva del modelo de color luz (RGB), la combinación de luz roja y luz verde genera luz amarilla.",
  },
  {
    id: "q20",
    category: "Matrices Abstractas",
    question: "¿Qué número completa la matriz 3×3? [1, 2, 3] / [2, 4, 6] / [3, 6, ?]",
    visual: { type: "matrix3x3" },
    options: ["9", "8", "12", "7"],
    correct: 0,
    explanation:
      "Cada fila es el producto del número base de la columna por el índice de la fila. En la tercera fila: 3×1=3, 3×2=6, 3×3=9.",
  },
  {
    id: "q21",
    category: "Razonamiento Lógico",
    question: "Si hoy es martes, ¿qué día de la semana será dentro de 15 días?",
    visual: { type: "weekday" },
    options: ["Miércoles", "Martes", "Jueves", "Lunes"],
    correct: 0,
    explanation:
      "15 días equivalen a 2 semanas completas (14 días) más 1 día extra. Por ende, un día después de martes es miércoles.",
  },
  {
    id: "q22",
    category: "Memoria y Velocidad",
    question: "Escribe el resultado de: 15 + 25 × 2 − 10",
    visual: { type: "mathExpr", expr: "15 + (25 × 2) − 10" },
    options: ["55", "70", "65", "50"],
    correct: 0,
    explanation:
      "Siguiendo la jerarquía matemática de operaciones: primero se resuelve la multiplicación (25 × 2 = 50), luego la suma y la resta: 15 + 50 − 10 = 55.",
  },
  {
    id: "q23",
    category: "Razonamiento Espacial",
    question: "Si desdoblas un cubo de cartón, ¿cuántas caras cuadradas posee en total?",
    visual: { type: "cubeNet" },
    options: ["6 caras", "4 caras", "8 caras", "5 caras"],
    correct: 0,
    explanation:
      "Un cubo geométrico tridimensional está compuesto exactamente por 6 caras cuadradas idénticas.",
  },
  {
    id: "q24",
    category: "Lógica Numérica",
    question: "¿Cuál es el valor de X? 3, 6, 12, 24, X",
    visual: { type: "chips", items: ["3", "6", "12", "24", "X"] },
    options: ["48", "36", "42", "60"],
    correct: 0,
    explanation: "Cada término es el doble del anterior (× 2). Por lo tanto: 24 × 2 = 48.",
  },
  {
    id: "q25",
    category: "Analogías Verbales",
    question: "PINTOR es a PINCEL como ESCULTOR es a:",
    visual: {
      type: "analogy",
      left: "PINTOR",
      right: "PINCEL",
      target: "ESCULTOR",
    },
    options: ["Cincel", "Mármol", "Estatua", "Lienzo"],
    correct: 0,
    explanation:
      "El pincel es la herramienta de trabajo principal del pintor, así como el cincel es la herramienta fundamental del escultor.",
  },
];
