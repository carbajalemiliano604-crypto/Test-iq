import type { HistoryEntry, LeaderboardEntry, ThemeId } from "./types";
import { THEME_IDS } from "./types";

const LB_KEY = "iq_app_leaderboard";
const HIST_KEY = "iq_app_history";
const THEME_KEY = "iq_app_theme";
const NAME_KEY = "iq_app_username";

function canUseStorage() {
  return typeof window !== "undefined";
}

function readJson<T>(key: string, fallback: T): T {
  if (!canUseStorage()) return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadLeaderboard(): LeaderboardEntry[] {
  const data = readJson<LeaderboardEntry[]>(LB_KEY, []);
  return Array.isArray(data) ? data : [];
}

export function saveLeaderboard(entries: LeaderboardEntry[]) {
  if (!canUseStorage()) return;
  localStorage.setItem(LB_KEY, JSON.stringify(entries));
}

export function addLeaderboardEntry(entry: LeaderboardEntry): {
  rank: number;
  total: number;
} {
  const lb = [...loadLeaderboard(), entry];
  lb.sort((a, b) => {
    if (b.iq !== a.iq) return b.iq - a.iq;
    return a.timeSeconds - b.timeSeconds;
  });
  saveLeaderboard(lb);
  const rank = lb.findIndex((item) => item === entry) + 1;
  return { rank, total: lb.length };
}

export function clearLeaderboard() {
  if (!canUseStorage()) return;
  localStorage.removeItem(LB_KEY);
}

export function loadHistory(): HistoryEntry[] {
  const data = readJson<HistoryEntry[]>(HIST_KEY, []);
  return Array.isArray(data) ? data : [];
}

export function saveHistory(entries: HistoryEntry[]) {
  if (!canUseStorage()) return;
  localStorage.setItem(HIST_KEY, JSON.stringify(entries.slice(0, 40)));
}

export function pushHistory(entry: HistoryEntry) {
  saveHistory([entry, ...loadHistory()]);
}

export function clearHistoryStore() {
  if (!canUseStorage()) return;
  localStorage.removeItem(HIST_KEY);
}

export function loadTheme(): ThemeId {
  if (!canUseStorage()) return "indigo";
  const raw = localStorage.getItem(THEME_KEY) ?? "indigo";
  const id = raw.replace("theme-", "") as ThemeId;
  return THEME_IDS.includes(id) ? id : "indigo";
}

export function saveTheme(id: ThemeId) {
  if (!canUseStorage()) return;
  localStorage.setItem(THEME_KEY, id);
}

export function loadUsername(): string {
  if (!canUseStorage()) return "";
  return localStorage.getItem(NAME_KEY) ?? "";
}

export function saveUsername(name: string) {
  if (!canUseStorage()) return;
  localStorage.setItem(NAME_KEY, name);
}
